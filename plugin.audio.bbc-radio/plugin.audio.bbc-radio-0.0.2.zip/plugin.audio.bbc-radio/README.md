plugin.audio.bbc-radio
======================

Kodi Addon for listening to BBC Radio live broadcasts

BBC Radio is an operational business division and service of the British Broadcasting Corporation. The service provides national radio stations covering the majority of musical genres, as well as local radio stations covering local news, affairs and interests.