#!/usr/bin/env python
# -*- coding: UTF-8 -*-

#
# Constants
# 
ADDON = "plugin.video.ted.talks"
DATE = "2017-05-26"
VERSION = "4.2.12-SNAPSHOT"