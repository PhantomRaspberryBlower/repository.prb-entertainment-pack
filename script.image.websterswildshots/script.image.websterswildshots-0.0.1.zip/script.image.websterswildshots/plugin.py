#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import urlparse

import xbmc
import xbmcgui
import xbmcplugin

from websterswildshots import ScraperManager


def show_photos(scraper_id, album_url):
    scraper_manager = ScraperManager()
    scraper_manager.switch(scraper_id)
    for photo in scraper_manager.get_photos(album_url):
        li = xbmcgui.ListItem(
            label=photo['title'],
            thumbnailImage=photo['pic']
        )
        li.setInfo(type='image', infoLabels={'Title': photo['title']})
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=photo['pic'],
            listitem=li,
            isFolder=False
        )
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def decode_params():
    params = {}
    p = urlparse.parse_qs(sys.argv[2][1:])
    for key, value in p.iteritems():
        params[key] = value[0]
    log('params=%s' % params)
    return params


def message(message, title):
    # Display message to user
    dialog = xbmcgui.Dialog()
    dialog.ok(title, message)


def log(msg):
    xbmc.log('WebstersWildshots Plugin: %s' % msg)


if __name__ == '__main__':
    log('run started in photos-mode')
    params = decode_params()
    message(str(params), "Params")
    scraper_id = int(params['scraper_id'])
    album_url = params['album_url']
    show_photos(scraper_id, album_url)
