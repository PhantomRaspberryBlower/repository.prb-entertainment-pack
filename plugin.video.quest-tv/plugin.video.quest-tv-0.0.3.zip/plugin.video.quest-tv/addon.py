#!/usr/bin/python

import urllib
import urllib2
import xbmcplugin
import xbmcaddon
import xbmcgui
import re
import sys
from HTMLParser import HTMLParser

# Written by: Phantom Raspberry Blower (The PRB)
# Date: 21-12-2017
# Description: Addon for watching Quest TV on demand

# Get addon details
__addon_id__ = 'plugin.video.quest-tv'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
__fanart__ = __addon__.getAddonInfo('fanart')
__author__ = 'Phantom Raspberry Blower'
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])
__baseurl__ = 'https://www.questtv.co.uk'
_policy_key_url_ = 'https://players.brightcove.net/%s/%s_%s/index.min.js'

# Get localized language text
__language__ = __addon__.getLocalizedString
_unable_to_download_page = __language__(30101)
_error = __language__(30102)
_something_wicked_happened = __language__(30103)
_unable_to_download_stream = 'Unable to download streams :(' #__language__(30101)

hp = HTMLParser()

def message(message, title):
    # Display message to user
	dialog = xbmcgui.Dialog()
	dialog.ok(title, message)


def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		r = re.search("(?i)" + from_string +
					  "([\S\s]+?)" +
					  to_string, text).group(1)
	else:
		r = re.search("(?i)(" +
					  from_string +
					  "[\S\s]+?" +
					  to_string +
					  ")", text).group(1)
	return r


def get_policy_key(account, player, embedid):
	policy_key = ''
	url = _policy_key_url_ % (account, player, embedid)
	html = get_html(url)
	match = re.compile('{accountId:"%s",policyKey:"(.+?)"}' % account).findall(html)
	for pk in match:
		policy_key = str(pk)
	return policy_key


def play_stream(name, url, thumbnail):
	liz = xbmcgui.ListItem(name)
	liz.setArt({'thumb': thumbnail})
	xbmc.Player().play(url, liz)
	sys.exit("Stop Video")


def show_streams(name, url, account, player, embedid):
	policy_key = str(get_policy_key(account, player, embedid))
	html = get_html(url, policy=policy_key)
	try:
		episode = regex_from_to(str(html), '"batch:on","', '","form:long"')
		series = regex_from_to(str(html), '"rating:pg","', '","show:')
		topic = regex_from_to(str(html), '"site:quest uk","', '"],"cue_points"')
	except:
		pass
	try:
		plot = regex_from_to(str(html), '"description":"', '"')
		fanart = regex_from_to(str(html), '"src":"', '"')
		thumb = regex_from_to(str(html), '"thumbnail":"', '"')
		name = regex_from_to(str(html), '],"name":"', '"')
		html = regex_from_to(str(html), '"sources"', '"name"')
		match = re.compile('"width":(.+?),"(.+?)":"(.+?)","size":(.+?),"height":(.+?),"duration":(.+?),"container"').findall(str(html))
		for width, junk, link, size, height, duration in sorted(match):
			if junk == 'src':
				title = name + " (%s x %s)" % (str(width), str(height))
				dur = int(int(duration)/1000)
				add_directory(title, link, 4, fanart, thumb, infoLabels={'Title': title, 'plot': plot, 'duration': dur})
		hd_stream = regex_from_to(html, '"type":"application/x-mpegURL","src":"', '","container":"M2TS",')
		if len(hd_stream) > 0:
			title = name + ' (M2TS)'
			add_directory(title, hd_stream, 4, fanart, thumb, infoLabels={'Title': title, 'plot': plot, 'duration': dur})
	except:
		message(_unable_to_download_stream, "Error!")


def all_shows():
	url = __baseurl__ + '/shows/'
	html = get_html(url)
	html = html.replace('\n', '').replace('  ', '').replace('\t', '').replace('\\', '')
	html = regex_from_to(html, '<!--1 column -->', '</main>')
	match = re.compile('<h2>(.+?)</h2></div></div><div class="image parbase"><div '
					   'class="cfct-module dni-image fullWidthHeading"><div class='
					   '"dni-image "><div>(.+?)<img src="(.+?)"/>').findall(html)
	for title, link, img in sorted(match):
		link = regex_from_to(link, '<a href="', '">')
		if link:
			title = title.title()
			title = hp.unescape(title).replace("'S", "'s")
			img = __baseurl__ + img
			addDir(title, link, 2, img)


def shows(filterShow=None):
	data_account = ''
	data_player = ''
	data_embed = ''
	html = get_html(__baseurl__ + '/content/discovery/neur/uk/questtv/video/jcr:con'
					'tent/root/columns_container_1/column1/brightcove_video_lis.content')
	html = html.replace('\n', '').replace('  ', '').replace('\t', '').replace('\\', '')
	player_data = re.compile('<video id="(.+?)" data-video-id="(.+?)" data-account="(.+?)" dat'
							 'a-player="(.+?)" data-embed="(.+?)" data-application-id class="(.+?)"'
							 ' controls></video>').findall(html)
	try:
		for vi, dvi, da, dp, de, dai in player_data:
			data_account = da
			data_player = dp
			data_embed = de
	except:
		message(_unable_to_download_page, _error)
	match = re.compile('<div class="dni-video-playlist-thumb-box(.+?)"><a href="(.+?)"><span '
					   'class="dni-video-playlist-thumb-number">(.+?)</span><span class="dni-'
					   'video-playlist-thumb-image">(.+?)<img src="(.+?)" alt="(.+?)"/>(.+?)<'
					   'div class="dni-video-playlist-thumb-info"><h3>(.+?)</h3><h3 class="de'
					   'scHidden">(.+?)</h3><p class="desc">(.+?)</p><p class="descHidden">'
					   '(.+?)</p>').findall(html)
	if filterShow:
		match = sorted(match)
	for junk, link, num, junk1, img, alt, junk2, img_info, title, brief_desc, plot in match:
		title = hp.unescape(title).replace("'S", "'s")
		link = 'https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/%s' % (data_account, link.replace('#', ''))
		infoLabels = {'Title': title, 'plot': plot}
		if filterShow:
			if filterShow in title:
				addDir(title, link, 3, img, infoLabels=infoLabels, account=data_account, player=data_player, embedid=data_embed)
		else:
			addDir(title, link, 3, img, infoLabels=infoLabels, account=data_account, player=data_player, embedid=data_embed)
	xbmcplugin.endOfDirectory(__handle__)


def menu():
	data_account = ''
	data_player = ''
	data_embed = ''
	addDir('[COLOR orange]All Shows[/COLOR]', __baseurl__ + '/shows/',1,__icon__)
	shows()


def add_directory(name,url,mode,fanart,thumbnail,infoLabels):
	u=sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&thumb=" + urllib.quote_plus(thumbnail)
	ok=True
	liz=xbmcgui.ListItem(name)
	if not infoLabels:
		infoLabels = {"Title": name}
	liz.setInfo(type="Video", infoLabels=infoLabels)
	if not fanart:
		fanart=__fanart__
	liz.setArt({'fanart': fanart,
				'thumb': thumbnail})
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False, totalItems=10)
	return ok


def addDir(name, url, mode, iconimage, fanart=False, infoLabels=True, account=None, player=None, embedid=None):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&account=" + str(account) + "&player=" + str(player) + "&embedid=" + str(embedid) + "&thumb=" + str(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name)
	if not infoLabels:
		infoLabels =  {"Title": name}
	liz.setInfo(type="Video", infoLabels=infoLabels)
	liz.setProperty('IsPlayable', 'true')
	if not fanart:
		fanart = __fanart__
	liz.setArt({'fanart': fanart,
				'thumb': iconimage})
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
	return ok


def get_html(url, policy=None):
	header_dict = {}
	header_dict['Accept'] = 'application/json;pk=' + str(policy)
	header_dict['User-Agent'] = 'AppleWebKit/<WebKit Rev>'
	req = urllib2.Request(url, headers=header_dict)
	try:
		response = urllib2.urlopen(req)
		html = response.read()
		response.close()
	except urllib2.HTTPError:
		response = False
		html = False
	return html


def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params) - 1] == '/'):
			params = params[0:len(params) - 2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]

	return param


''' Main '''
params = get_params()
url = None
name = None
mode = None
account = None
player = None
embed_id = None
thumb = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	account = int(params["account"])
except:
	pass
try:
	player = params["player"]
except:
	pass
try:
	embed_id = params["embedid"]
except:
	pass
try:
	thumb = urllib.unquote(params["thumb"])
except:
	pass

# message("Mode: %s\nURL: %s\nName: %s" % (mode, url, name), "Test")

if mode == None or url == None or len(url) < 1:
	menu()
elif mode == 1:
	all_shows()
elif mode == 2:
	shows(name)
elif mode == 3:
	show_streams(name, url, account, player, embed_id)
elif mode == 4:
	if not thumb:
		thumb = __icon__
	play_stream(name, url, thumb)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
