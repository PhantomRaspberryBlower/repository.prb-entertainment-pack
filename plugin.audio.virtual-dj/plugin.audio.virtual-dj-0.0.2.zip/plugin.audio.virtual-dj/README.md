![Virtual DJ logo](https://github.com/PhantomRaspberryBlower/plugin.audio.virtual-dj/blob/master/resources/icon.png)

plugin.video.virtual-dj
=======================

Kodi Addon for listening to Virtual DJ live broadcasts

