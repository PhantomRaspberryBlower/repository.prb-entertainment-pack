plugin.video.virtual-dj
======================================

Kodi Addon for listening to live streams from Virtual DJ

Virtual DJ music streams.