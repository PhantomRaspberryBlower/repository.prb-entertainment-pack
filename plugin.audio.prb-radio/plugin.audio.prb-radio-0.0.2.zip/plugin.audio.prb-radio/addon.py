#!/bin/python

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from xml.etree import ElementTree
import sys
import urllib
import urllib2
import os
import re

from resources.lib.artistinfo import ArtistInfo
import thread

# Written by:	Phantom Raspberry Blower
# Date:		21-02-2017
# Description:	Addon for listening to PRB Radio live broadcasts

# Get addon details
__addon_id__ = 'plugin.audio.prb-radio'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
__fanart__ = __addon__.getAddonInfo('fanart')
__author__ = "Phantom Raspberry Blower"
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

# Get localized language words
__language__ = __addon__.getLocalizedString
_prb_radio = __language__(30101)
_status = __language__(30102)
_unplayable_stream = __language__(30103)
_something_wicked_happened = __language__(30104)
_error = __language__(30105)
_please_wait = __language__(30106)
_process_complete = __language__(30107)
_failed_to_download_links = __language__(30108)
_logged_into_prb_radio = __language__(30109)
_login_success_ = __language__(30110)
_failed_to_log_into_prb_radio = __language__(30111)
_login_failed = __language__(30112)
_artist_info = __language__(30113)
_unable_to_download_artist_info = __language__(30114)
_no_artist_name_present = __language__(30115)
_no_audio_stream = __language__(30116)
_settings = __language__(30117)
_prb_desc = __language__(30118)
_artist_info_desc = __language__(30119)
_settings_desc = __language__(30120)
_prb_radio_not_broadcasting = __language__(30121)
_on_air = __language__(30122)
_off_air = __language__(30123)

playable_url = ''
base_url = 'http://dir.xiph.org/search?search=PRB+Leicester'

# Get addon user settings
_hide_artist_info = __addon__.getSetting('hide_artist_info')
_hide_artist_artwork = __addon__.getSetting('hide_artist_artwork')

# Define local variables
g_default_image = None
image_path = xbmc.translatePath(os.path.join('special://home/addons/',
	                            __addon_id__ + '/resources/media/'))
links_info = {_prb_radio:
              {'thumbs': os.path.join(image_path, 
                                      'prb_radio.png'),
               'fanart': os.path.join(image_path,
                                      'prb_radio_fanart.jpg'),
               'desc': _prb_desc
               },
              _artist_info:
              {'thumbs': os.path.join(image_path,
                                      'artist_info.png'),
               'fanart': os.path.join(image_path,
                                      'artist_info_fanart.jpg'),
               'desc': _artist_info_desc
               },
              _settings:
              {'thumbs': os.path.join(image_path,
                                      'settings.png'),
               'fanart': os.path.join(image_path,
                                      'settings_fanart.jpg'),
               'desc': _settings_desc
               }
              }


def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        r = re.search("(?i)" + from_string +
                      "([\S\s]+?)" +
                      to_string, text).group(1)
    else:
        r = re.search("(?i)(" +
                      from_string +
                      "[\S\s]+?" +
                      to_string +
                      ")", text).group(1)
    return r


def get_stream_link():
    # Get list of live links and channel statistics
    url = base_url
    link = ''
    location = ''
    content = urllib2.urlopen(url).read()
    content = content.replace('\n', '').replace('\t', '')
    streams = re.compile('<tr class="(.+?)">(.+?)</tr>').findall(content)
    for row_id, stream in streams:
        match = re.compile('<p class="stream-name"><span class="name"><a href="(.+?)"(.+?)>(.+?)</a(.+?)>M3U</a>(.+?)<a href="(.+?).xspf"').findall(stream)
        for search, junk, name, junk2, junk3, xspf in match:
            if name == 'PRB Radio':
            	link = 'http://dir.xiph.org' + xspf + '.xspf'
    content = urllib2.urlopen(link).read()
    title = regex_from_to(content, '<title>', '</title>')
    if title == 'PRB Radio':
        location = regex_from_to(content, '<location>', '</location>')
    else:
        return 0
    return location


def addDir(name, url, mode, icon, fanart, desc, isFolder=False, IsPlayable=False):
    """
    Display a list of links
    """
    u = (sys.argv[0] + '?url=' + urllib.quote_plus(url) +
         '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) +
         '&icon=' + str(icon) + '&fanart=' + str(fanart))
    ok = True
    liz = xbmcgui.ListItem(name)

    # Set fanart and thumb images for the list item.
    if not fanart:
        fanart = __fanart__
    if not icon:
        icon = __icon__
    if IsPlayable == True:
        liz.setProperty('IsPlayable', 'true')
    liz.setArt({'fanart': fanart,
                'thumb': icon})

    # Set additional info for the list item.
    liz.setInfo(type='music',
                infoLabels={'title': name,
                            'artist': name,
                            'description': desc,
                            'genre': 'Internet Radio',
                            'year': 2019,
                            'mediatype': 'album'
                            }
                )
    ok = xbmcplugin.addDirectoryItem(handle=__handle__,
                                     url=u,
                                     listitem=liz,
                                     isFolder=isFolder)
    return ok


def main_menu():
    playable_url = get_stream_link()
    addDir(_prb_radio,
           playable_url,
           1,
           links_info[_prb_radio]['thumbs'],
           links_info[_prb_radio]['fanart'],
           links_info[_prb_radio]['desc'],
           isFolder=False, IsPlayable=True)
    if _hide_artist_info != 'true':
        addDir(_artist_info,
               'XBMC.RunPlugin({0}?url=artistinfo&mode=4)',
               4,
               links_info[_artist_info]['thumbs'],
               links_info[_artist_info]['fanart'],
               links_info[_artist_info]['desc'],
               isFolder=False)
    addDir(_settings,
           'XBMC.RunPlugin({0}?url=settings&mode=5)',
           5,
           links_info[_settings]['thumbs'],
           links_info[_settings]['fanart'],
           links_info[_settings]['desc'],
           isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)


def get_audio(name, url, icon, fanart):
    """
    Parse the file location and title links from audio stream location.
    """
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)
    while not xbmc.Player().isPlayingAudio():
        xbmc.sleep(3)
    thread.start_new_thread( _show_artist_image,())


def get_artist_name():
    if xbmc.Player().isPlayingAudio():
        title = xbmc.Player().getMusicInfoTag().getTitle()
        if len(title) > 0:
            items = title.split(' - ')
            artist_name = items[0]
            if len(artist_name) > 1:
                return artist_name
            else:
                return False
        else:
            notification(_no_artist_name_present, _artist_info, __icon__, 5000)
            return False
    else:
        message(_no_audio_stream, _artist_info)
        return False


def show_artist_details(artistname):
    artist_info = ArtistInfo(artistname)
    try:
        home = xbmc.translatePath('special://home')
        if xbmc.getInfoLabel('System.ProfileName') != 'Master user':
            you = xbmc.getInfoLabel('System.ProfileName')
        elif (xbmc.getCondVisibility('System.Platform.Windows') is True or
              xbmc.getCondVisibility('System.Platform.OSX') is True):
            if 'Users\\' in home:
                proyou = str(home).split('Users\\')
                preyou = str(proyou[1]).split('\\')
                you = preyou[0]
            else:
                you = 'You'
        else:
            you = 'You'
        window = xbmcgui.WindowXMLDialog('plugin-audio-prb-radio.xml',
                                         __addon__.getAddonInfo('path'))
        win = xbmcgui.Window(10147)
        win.setProperty('HeadingLabel',
                        artistname)
        # Property can be accessed in the XML using:
        # <label fallback="416">$INFO[Window(10147).Property(HeadingLabel)]</label>
        win.setProperty('ArtistImage',
                        artist_info.fanart)
        win.setProperty('ArtistStyle',
                        artist_info.style)
        win.setProperty('ArtistGenre',
                        artist_info.genre)
        win.setProperty('ArtistName',
                        artist_info.artist_name)
        win.setProperty('ArtistFormed',
                        str(artist_info.year_formed).replace('None', ''))
        win.setProperty('ArtistBorn',
                        str(artist_info.year_born).replace('None', ''))
        win.setProperty('ArtistDied',
                        str(artist_info.year_died).replace('None', ''))
        win.setProperty('ArtistGender',
                        artist_info.gender)
        win.setProperty('ArtistCountry',
                        artist_info.country.replace('None', '') + ' ' +
                        artist_info.country_code.replace('None', ''))
        win.setProperty('ArtistWebsite',
                        artist_info.website)
        win.setProperty('Description',
                        artist_info.biography_en)
        window.doModal()
        del window
    except:
        notification(_unable_to_download_artist_info, _artist_info, __icon__, 5000)


def get_current_artist_image():
    """
    Discover artist name, download image and return the image path
    if no image can be found return the default image instead
    """
    global g_default_image
    # Find the current artist name
    artist_name = get_artist_name()
    if artist_name != False:
        if len(artist_name) > 1:
            # Find the artist information
            artist_info = ArtistInfo(artist_name)
            if artist_info != 0:
                try:
                    if len(artist_info.fanart) > 1:
                        return artist_info.fanart
                    else:
                        return g_default_image
                except:
                    return g_default_image
            else:
                return g_default_image
        else:
            return g_default_image
    else:
        return g_default_image


def _show_artist_image():
    global g_default_image
    window = xbmcgui.WindowXMLDialog('plugin-music-visualisation.xml',
                                     __addon__.getAddonInfo('path'))
    win = xbmcgui.Window(12006)
    window.show()
    try:
        if xbmc.Player().isPlayingAudio():
            my_title = xbmc.Player().getMusicInfoTag().getTitle()
        previous_title = ''
        # main loop
        while (not xbmc.Monitor().abortRequested() and
               xbmc.Player().isPlayingAudio()):
            if _hide_artist_artwork != 'true':
                try:
                    my_title = xbmc.Player().getMusicInfoTag().getTitle()
                    if my_title != previous_title:
                        # check if we are on the music visualization screen
                        # do not try and set image for any background media
                        previous_title = my_title
                        if xbmc.getCondVisibility("Player.IsInternetStream"):
                            artist_image = get_current_artist_image()
                            if len(artist_image) > 0:
                                win.setProperty('ArtistFanart',
                                                artist_image)
                            else:
                                win.setProperty('ArtistFanart', g_default_image)
                except:
                    win.setProperty('ArtistFanart', g_default_image)
            else:
                win.setProperty('ArtistFanart', g_default_image)
            xbmc.sleep(1000)
    except:
        pass
    del window


def get_params():
    """
    Parse the paramters sent to the application
    """
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


def notification(heading, message, icon, duration):
    # Show message notification
    dialog = xbmcgui.Dialog()
    dialog.notification(heading, message, icon, duration)


def message(message, title):
    # Display message to user
    dialog = xbmcgui.Dialog()
    dialog.ok(title, message)


# Define local variables
params = get_params()
url = None
name = None
mode = None
icon = None
fanart = None

# Parse the url, name, mode, icon and fanart parameters
try:
    url = urllib.unquote_plus(params['url'])
except:
    pass
try:
    name = urllib.unquote_plus(params['name'])
except:
    pass
try:
    mode = int(params['mode'])
except:
    pass
try:
    icon = urllib.unquote_plus(params['icon'])
except:
    pass
try:
    fanart = urllib.unquote_plus(params['fanart'])
except:
    pass

# Route the request based upon the mode number
if mode is None or url is None or len(url) < 1:
    main_menu()
elif mode == 1:
    # Start audio stream
    g_default_image = fanart
    xbmc.executebuiltin('Action(Fullscreen)')
    get_audio(name, url, icon, fanart)
elif mode == 4:
    # Show artist description
    artist_name = get_artist_name()
    if artist_name != False:
        if artist_name != None:
            show_artist_details(artist_name)
#            xbmc.executebuiltin('Action(Fullscreen)')
            thread.start_new_thread( _show_artist_image,())
elif mode == 5:
    __addon__.openSettings()
    xbmc.executebuiltin("Container.Refresh")

xbmc.PlayList(0).clear()
#xbmcplugin.endOfDirectory(__handle__)
