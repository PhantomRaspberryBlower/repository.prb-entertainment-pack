"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, re, sys, string, json, random, base64

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

from resources.lib.modules.common import *

art = 'special://home/addons/script.module.jhm/lib/resources/art/'

#==========================================================================================================

channellist=[
        ("[B]ROW: Alex Gracia, Rok-C vs Myka, Promise Braxton - Lucha Libre Texas City 5/28/20[/B]", "s7n6KAEnM88", 801, "WOMEN, ROW", art+'row.jpg', fanart),    
        ("[B]AEW Thunder Rosa v Nyla Rose, Final US Bracket: Women Eliminator Tournament (3/2/21)[/B]", "4YMpWyKG6Dk", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]TMW: 30 Woman Battle Royal (2013)[/B]", "EsyJQliAAiA", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Impact: Abyss vs Bully Ray: MONSTERS BALL TNA Genesis 2012[/B]", "r1n3iyDAD84", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]RISE of The Contender - 30 Woman Ordered Entry Battle Royal [/B]", "ww7A0j-UCOQ", 801, "WOMEN, MISC", art+'women.jpg', fanart),
        ("[B]ROH: Briscoe Brothers vs 2 Guys 1, Tag Final Battle Fallout 2019[/B]", "jRT76KSN3L8", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]WWE: Triple H vs Brock Lesnar, No Holds Barred Match WrestleMania 29[/B]", "CgJ18rBMm1g", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Flair vs Banks vs Bayley, WWE Clash of Champions 2016[/B]", "UWZAy31edkY", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Big Show vs Braun Strowman, Steel Cage Match, 9/4/2017[/B]", "Pqqjsj9IZic", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: John Cena vs Seth Rollins, US Title Steel Cage Match[/B]", "os9VL8h3hkI", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Randy Orton vs John Cena vs Triple H, Night of Champions 2009[/B]", "BwtC7qNSRxQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Undertaker No Holds Barred Match WrestleMania 33[/B]", "oC4svcyIhg4", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs. John Cena, No Mercy 2017[/B]", "hjUsCZ5i1yc", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Brock Lesnar vs The Undertaker, SummerSlam 2015[/B]", "sBBFSuHATmw", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Seth Rollins vs Kane, Hell in a Cell 2015[/B]", "kPE4MIjc7HI", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Adam Cole vs Johnny Gargano, 2-Out-Of-3 Falls, NXT TakeOver Toronto[/B]", "Wt26c_8QZYY", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Sheamus vs Big Show, WWE Hell in a Cell 2012[/B]", "DLhLHrTLolc", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: 20-Woman Battle Royal, WWE Evolution 2018[/B]", "70a_NIXZ2JI", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: John Cena vs Big Show, Steel Cage Match No Way Out 2012[/B]", "YRnYEhUvoRA", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Seth Rollins, Raw May 29, 2017[/B]", "BAxabn2-QAA", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: AJ Styles vs Randy Orton WrestleMania 35[/B]", "vh3jL__8150", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WCW: Kevin Nash vs Goldberg, Goldbergs 1st Loss Starcade 1998[/B]", "gkdxtl1_lq0", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]WWE: John Cena vs. Bray Wyatt Last Man Standing Match WWE Payback 2014[/B]", "UbZSY0b6yEo", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Randy Orton vs Mark Henry WWE Night of Champions 2011[/B]", "d_RsPFu54mo", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: WWE Championship Scramble Match WWE Unforgiven 2008[/B]", "gmpwAm2jEXE", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Big Show Last Man Standing Match Extreme Rules 2015[/B]", "aQ4Dlrbxax0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Brock Lesnar vs Roman Reigns Universal Title Match SummerSlam 2018[/B]", "nSNkwIvlWJU", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Kurt Angle vs Undertaker World Heavyweight Title No Way Out 2006[/B]", "t_9c9Px7Eac", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Charlotte Flair vs Natalya Womens Title Match Payback 2016[/B]", "GTWdIMVOk88", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Cesaro Intercontinental Title Match 12/11/2017[/B]", "DBYHOFC0mGc", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Seth Rollins vs Triple H WrestleMania 33[/B]", "48Y_zYZ5EDk", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Cesaro vs Sheamus Clash of Champions 2016[/B]", "7JVFCKxwkPs", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Baron Corbin Universal Title Match 9/17/2018[/B]", "XsM2Fi8J4zw", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Miz vs Roman Reigns Intercontinental Title Match 11/20/2017[/B]", "KZp8L_HoeuY", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Seth Rollins vs John Cena US Title Match Night of Champions 2015[/B]", "bTXOAaaCnkQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Orton vs Bryan WWE Title Match Night of Champions 2013[/B]", "dw2pk6U3HgQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Kane vs Undertaker World Heavyweight Title Match Night of Champions 2010[/B]", "a2VLZ90mjVg", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Braun Strowman vs Bobby Lashley Last Man Standing Match Extreme Rules 2019[/B]", "dtVSCeEOL3E", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Braun Strowman WWE Payback 2017[/B]", "HpqHxoYJ-sQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: The Rock vs Brock Lesnar WWE Undisputed Title Match SummerSlam 2002[/B]", "zOH89G2OLAU", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: SmackDown Womens Title Lumberjack Match Clash of Champions 2017[/B]", "8GLTR3DYFFw", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Nikki Bella vs Charlotte Night of Champions 2015[/B]", "RHFAwdWW6BU", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Baszler vs Belair vs Shirai vs Sane NXT TakeOver New York[/B]", "JBD54QpdePg", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Charlotte Flair vs Trish Stratus SummerSlam 2019[/B]", "WI2rU01L6Z0", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: First Ever 30 Woman Championship Royal Rumble Match 2018[/B]", "BKlgU9HPvdU", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: NXT Womens No. 1 Contender Battle Royale 2020[/B]", "i9a-jvRaFYE", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Becky Lynch vs Charlotte Flair WWE Evolution[/B]", "jolQfrzjOR4", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: Bayley vs Banks 30-Minute Iron Man Match NXT TakeOver Respect[/B]", "l29mwpuKLJs", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]Zelo Pro Tessa Blanchard vs Kylie Rae Womens Championship 1/4/19[/B]", "T-oJnJkXj-Q", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]TMW: Kiera Hogan vs Diamante - Ladies Night Out VIII (2019)[/B]", "vh29qKGiCNc", 801, "WOMEN", art+'tmn.jpg', fanart),    
        ("[B]EVE: Six Woman Ladder Match 2020[/B]", "6mT2CZtnXWo", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Womens Steel Cage War Games 2020[/B]", "H-_nTrzIXJY", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Jamie Hayter vs Roxxy 2020[/B]", "z7uSttlPC34", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Kay Lee Ray vs Viper Piper Niven 2020[/B]", "gCyn0iPfJ_M", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Kay Lee Ray vs Sammii Jayne 2020[/B]", "zpRx28I-WEc", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Mercedes Martinez vs Nightshade 2020[/B]", "6DeSKKT4Hm8", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Kay Lee Ray vs Charlie Morgan 2020[/B]", "H4SuSzlyDtc", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]EVE: Nina Samuels vs Nicole Matthews 2020[/B]", "Fp6gKHd4MF0", 801, "EVE, WOMEN", art+'eve.jpg', fanart),    
        ("[B]WWE: Royal Rumble Match 1992[/B]", "twHYY_hT-Y0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: The Miz vs Roman Reigns Intercontinental Title Match 12/20/2017[/B]", "KZp8L_HoeuY", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Randy Orton vs. Dolph Ziggler Night of Champions 2012[/B]", "Ra6rWizbXYc", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Becky Lynch vs Sasha Banks Clash of Champions 2019[/B]", "hWI8tAhFteA", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WAW: Bellatrix 5 Women Tag Team Elimination 3/12/20[/B]", "Kkat3O89OSI", 801, "WOMEN, WAW", art+'waw.jpg', fanart),
        ("[B]AEW: Santana N Ortiz vs Best Friends Parking Lot Match 9/16/20[/B]", "hHbpXJQ32c4", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW: Dark Order vs Private Party N Billy N Austin Gunn AEW Dark 9/15/20[/B]", "AZxhSepkSfA", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]WWE: Womens Royal Rumble Team NXT vs Team Raw vs Team SmackDown[/B]", "YqX7GlMAGHo", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE: 30 Man Royal Rumble Match (2007)[/B]", "P6uCqHlTUmM", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Royal Rumble Match (2001)[/B]", "T07umXWdoCo", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Impact: Feast Or Fired Match Turning Point 2007[/B]", "OJ_LvvbLvvs", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Sting vs. Hulk Hogan Bound For Glory 2011[/B]", "lCINhc9cce0", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]WWE: 20 Man Battle Royal - February 23, 1992[/B]", "k8Vl9NUIoFE", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: 41-Man Battle Royal bei SmackDown 2011[/B]", "iI2WsH0flq8", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Shimmer: Kana (Asuka) vs. Cheerleader Melissa 2014[/B]", "OZznEzuPHtU", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]ROH: Hania The Huntress vs Mandy Leon 2016[/B]", "apavEOiU5qg", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]OTT Wrestling: B Cool vs Orange Cassidy 2019[/B]", "0LPrD56-Aro", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH: The Briscoes vs Shinsuke Nakamura N Kazuchika Okada 2017[/B]", "Ut2Whc6xHjE", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH: EPIC Star-Studded Survival of the Fittest 2014[/B]", "XsHAo_WqWT8", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Beyond: Jordynne Grace vs. Orange Cassidy[/B]", "Kumxoll65_s", 801, "WOMEN, MISC", art+'beyond.jpg', fanart),
        ("[B]WrestleCircus: Shane Strickland vs. Brian Cage 2017[/B]", "rj6sYZYw_E8", 801, "MISC", art+'circus.jpg', fanart),
        ("[B]AEW: The Hybrid2 vs The Initiative with Leva Bates 8/18/20[/B]", "8RBYG0Dc_uk", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]NWA: Kat Green vs Barbi Hayden Womens Championship 2014[/B]", "AkspWkmJSdQ", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]Impact: Tag Team Gauntlet Match No Surrender 2007[/B]", "gjz0LW7YslQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: AJ Styles vs. Samoa Joe vs. Christopher Daniels 2005[/B]", "U28pyOAMXcI", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]ROH: Chris Hero vs Adam Cole 2-out-of-3 Falls[/B]", "mRGuUxxy5oM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]WWR: Penelope Ford vs. Barbi Hayden[/B]", "UJzOX2W_sYY", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]AEW: Private Party N SCU vs Lucha Brothers N The Butcher N The Blade 8/18/20[/B]", "h3uT6IiWhbE", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]WWE: Lesnar vs. Reigns vs. Joe vs. Strowman - SummerSlam 2017[/B]", "wWCaadq1woE", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Hardy Boys VS Young Bucks 2017[/B]", "PyhgGzFfUEg", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Crossfire: Matt Hardy VS MVP 2012[/B]", "W8HlSDMwiRo", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]WILL OSPREAY VS BANDIDO 2019[/B]", "mAcRO89Aw30", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Kevin Steen VS Tommy Dreamer - ECW Rules Match 2012[/B]", "A-CCsFboTEw", 801, "MISC", art+'misc.jpg', fanart),
        ("[B]Taeler Hendrix VS Allysin Kay[/B]", "SK8xJGmORag", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Su Yung VS Kimber Lee (Street Fight)[/B]", "siwh37sDaSI", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Penelope Ford VS Maria Manic (Grudge Match)[/B]", "tKTaTGQTYTI", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Limitless: Kris Statlander vs. Ashley Vox Last Creature Standing 2019[/B]", "Xcm0FPBT-xU", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Beyond: Kylie Rae/Penelope/Kimber/Skylar vs. Shotzi/Harlow/Twisted Sisterz[/B]", "JqSF28c1nXE", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]RESISTANCE Pro Wrestling: MELANIE CRUISE vs NIKKI ST. JOHN I QUIT MATCH 2017[/B]", "uoktIh443Vk", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]WWR Pro: Womens Revolutionary Rumble 2020[/B]", "ur6cwg9zZqU", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Impact: Knockouts Gauntlet Match Slammiversary 2020[/B]", "wgACmTBUYVQ", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Impact: Sam Callihan vs Pentagon Jr MEXICAN DEATH MATCH 2018[/B]", "zXQeIxg-L_4", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: AJ Styles vs Bully Ray - Last Man Standing 2011[/B]", "dlhaUW_dXKw", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Sting, Kurt Angle N Wild Card vs Aces N 8s 2013[/B]", "r30d4jXolHM", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Mr. Anderson vs. Sting - Slammiversary 2011[/B]", "pK0VGinSEe8", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]WrestleCircus:Tessa Blanchard vs Britt Baker 9/9/17[/B]", "fxyZ_DMp-gg", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]ROH: Bandido, Mysterio N Rey Fenix vs Young Bucks N Kota Ibushi[/B]", "ZIUvAJRW2zU", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH: Kenta vs Tyler Black[/B]", "qpJORGeDfxQ", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]WWE: Andre the Giant N Hacksaw Jim Duggan vs Kamala N Missing Link 1983[/B]", "0F-i8OQgLA8", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]AEW: SCU vs The Butcher N The Blade 8/11/20[/B]", "jeqoeuiR33M", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]ROH N PCW UK: Adam Cole vs Dave Mastiff 2015[/B]", "zjm3kb_LGlA", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Wrestlefest XVII: Maria Kanellis vs Mickie James 2013[/B]", "pBE971diLZw", 801, "MISC, WOMEN", art+'women.jpg', fanart),
        ("[B]Wrestlefest XVII: Goldust vs Mike Bennett 2013[/B]", "DTJTa8z2AEo", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Nova Pro Wrestling: Kimber Lee vs Veda Scott 2016[/B]", "Z2LaJwr7-1A", 801, "MISC, WOMEN", art+'women.jpg', fanart),
        ("[B]WWE: DX vs The Legacy - Summerslam 2009[/B]", "ngDPLckNU6A", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Randy Orton vs The Undertaker - SmackDown 2005[/B]", "JKjG1_ieiGs", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Impact: Kurt Angle vs Samoa Joe - Genesis 2006[/B]", "xccBlxbgvPQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Americas Most Wanted vs Triple X 2004[/B]", "PsyWFJ2wHKQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Monsters Ball Tag Team Match 2008[/B]", "dMhHDR9zwp8", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: AJ Styles vs Booker T - Sacrifice 2009[/B]", "Q5BTH-94YgM", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: 10-Man X-Division Steel Asylum Cage Match 2008[/B]", "4FwJ-Q_nq9c", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Victory Road Ultimate X Gauntlet Match 2007[/B]", "MEHAHyAmaNc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Northeast Wrestling: Kevin Steen vs Jerry Lawler 2014[/B]", "lbd7FqWSRpY", 801, "MISC, NEW", art+'new.jpg', fanart),
        ("[B]Beyond: Kris Statlander vs. Orange Cassidy vs. Kimber Lee[/B]", "Hym2C6UAGaQ", 801, "MISC", art+'beyond.jpg', fanart),
        ("[B]Wrestle Circus: Orange Cassidy vs. Gentleman Jervis[/B]", "_ILMpJOzUXM", 801, "MISC, CIRCUS", art+'circus.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2019[/B]", "Whx5LQh7Xmo", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2018[/B]", "pb5ZFNj1dvE", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2017[/B]", "R9IrfVjm7kQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2016[/B]", "eRCgW0zLmLk", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2015[/B]", "-N3BKeMH7eQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2014[/B]", "klWF0hiG__s", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2013[/B]", "WwHN-Ek_a-g", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2012[/B]", "MqsYH13TkFk", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2011[/B]", "h72pMCM8kXk", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE: Money In The Bank Match 2010[/B]", "3gsiKMbPqOU", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]AEW: Jon Moxley Vs Chris Jericho Resolution 2020[/B]", "KiRj5EFNC7k", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW: SCU vs Santana N Ortiz vs Private Party 7/28/20[/B]", "2P_pi-lspm4", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]Impact: Sting vs. Mick Foley Lockdown 2009[/B]", "G4becmaXrvM", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Barbed Wire Massacre 3 LAX vs oVe 2018[/B]", "dWBgF0qEGgc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Sting vs. Hulk Hogan Bound For Glory 2011[/B]", "lCINhc9cce0", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Beyond: Orange Cassidy vs. WARHORSE[/B]", "ih4TQjHNZo0", 801, "MISC", art+'beyond.jpg', fanart),
        ("[B]WWE: Charlotte Flair vs Bayley Manila 2019[/B]", "B_xCge7ypys", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]Beyond: Orange Cassidy & Chuck Taylor v Santana & Ortiz[/B]", "jVmLEEZ_9ys", 801, "MISC", art+'beyond.jpg', fanart),
        ("[B]Wrestlezone: Brian Cage vs Alexander Hammerstone[/B]", "so5FAz0ohPk", 801, "MISC", art+'misc.jpg', fanart),
        ("[B]Heritage Hall: Willie Mack vs. Samoa Joe - Nov 2013[/B]", "5whHwVfHUPQ", 801, "CHAMP, MISC", art+'misc3.jpg', fanart),
        ("[B]Prestige Wrestling: Su Yung vs Orange Cassidy 2019[/B]", "7UDgThl2GkE", 801, "MISC, WOMEN", art+'women.jpg', fanart),
        ("[B]ICW: Maria Manic vs. Chris Dickinson 2019[/B]", "c1z1EZxbPh0", 801, "MISC, WOMEN", art+'women.jpg', fanart),
        ("[B]ROH: Is This the Craziest Battle Royal in ROH History[/B]", "bJiRuU7rYus", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Deonna Purrazzo vs Santana Garrett: Project XX 2016[/B]", "YunokgK4MAQ", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Defiant: Jay Lethal vs. Zack Sabre Jr 2017[/B]", "HLuZDLZNK_4", 801, "MISC", art+'defiant.jpg', fanart),
        ("[B]Wrestle Circus: Tessa Blanchard vs. Brian Cage 2018[/B]", "itbdZuduPCU", 801, "MISC, CIRCUS", art+'circus.jpg', fanart),    
        ("[B]TMW: Ivelisse vs Rok-C[/B]", "GCE_seHdueo", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]WWN: Adam Cole vs. Walter (EVOLVE 107)[/B]", "6_8jqPV20sM", 801, "MISC", art+'evolve.jpg', fanart),
        ("[B]NJPW: Makabe & Honma vs Tama Tonga & Tanga Loa 2016[/B]", "X7ccb0NaoC8", 801, "NJPW, MISC", art+'njpw.jpg', fanart),
        ("[B]AEW N AAA: Kenny Omega y The Young Bucks Vs Lucha Brothers y Laredo Kid 2019[/B]", "El43Ch1ybc0", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]Defiant: Bullet Club vs The Prestige 2017[/B]", "LCDhl9uKA1A", 801, "MISC", art+'defiant.jpg', fanart),
        ("[B]ROH: RUSH vs Matt Taven Title Match[/B]", "EHvneIKEzhM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH: Evil Ascends Vs Bullet Club 10-Man War[/B]", "vcA2wmn2JUM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Wrestle Pro: Ryback vs Brian Cage 2018[/B]", "imWYbWLTRTo", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]ROH: Jeff Cobb vs Evil[/B]", "FtViuD25va0", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH: CM Punk Vs Samoa Joe 2019[/B]", "BpC7byrTu6I", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Beyond: Brian Cage vs Keith Lee 2016[/B]", "xo4ZmT16dmc", 801, "MISC", art+'beyond.jpg', fanart),
        ("[B]Shimmer: Hikaru Shida vs. Evie (Dakota Kai) 2014[/B]", "4mCyTleESmI", 801, "WOMEN", art+'shimmer.jpg', fanart),    
        ("[B]Shimmer: Candice LeRae vs. Athena (Ember Moon) 2014[/B]", "GuoBhOPcw6E", 801, "WOMEN", art+'shimmer.jpg', fanart),    
        ("[B]Impact: Bobboy Lashley vs MVP 2015[/B]", "4Y2dDz_tX9I", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact: Jeff Hardy Vs Abyss Monsters Ball 2013[/B]", "hmhFIzm-4Ng", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]ROH: Colt Cabana & PCO vs RUSH & Jeff Cobb 2019[/B]", "p91WNdNpn_I", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Championship Wrestling: Reno Scum vs Thatcher N Gulak 2015[/B]", "ck-HuVMjNMk", 801, "CHAMP, MISC", art+'champ.jpg', fanart),
        ("[B]Championship Wrestling: Wolf Zaddies vs Vermin[/B]", "NH-TIgkZuKQ", 801, "CHAMP, MISC", art+'champ.jpg', fanart),
        ("[B]WWE: Undertaker Vs Stone Cold Steve Austin Backlash 2002[/B]", "380Ql-7f8Co", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Impact: Kurt Angle vs Christian Cage vs Rhino: World Title[/B]", "UO5Uef_qs50", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]ROH: Keith Lee & Shane Taylor vs War Machine 2016[/B]", "9wCOmOsC1tI", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]PCW: Pentagon Jr. vs. Shane Strickland[/B]", "rFNFmzR8OnQ", 801, "PCW", art+'pcw.jpg', fanart),
        ("[B]Kana (Asuka) vs Hanako Nakamori 2016[/B]", "IyXMsvIzt64", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Hikaru Shida vs Arisa Nakajima 2016[/B]", "rSDwnkf4lpg", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Io Shirai & AZM & HZK Vs kairi Hojo(NXT's Kairi Sane) & Konami & Hiromi Mimura 2017[/B]", "vhYZ3CL1tLs", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Kana (Asuka) vs. Ayako Hamada SHIMMER 50: 2012[/B]", "6eKQ2YZ0-_0", 801, "WOMEN, SHIMMER", art+'shimmer.jpg', fanart),
        ("[B]Kana(Asuka) & Arisa Nakajima vs Syuri & Hikaru Shida 2016[/B]", "ZeRyxx8nTRo", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]RPW Melanie Gruise VS Nikki St. John: I Quit Match 2017[/B]", "uoktIh443Vk", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]AWE Wrestling: Isla Dawn Vs Ivelisse 2017[/B]", "wcuCNNXHn-0", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Impact: Knockouts Lockbox Match (05.04.10)[/B]", "FCeUCeq7VD8", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]TNT Extreme Wrestling: Pete Dunne vs Will Ospreay 2019[/B]", "6_Ed2Xc8i0Y", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Impact: EC3 vs James Storm: Slammiversary 2017[/B]", "em6XFrJFJu4", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact X Division Xscape Match: Lockdown 2007[/B]", "ESJwP6GQbqQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]WOH Six Women Tag: LEON, SAKAI, ROSE vs SCOTT, HENDRIX, KIMURA[/B]", "wediUw3UBZs", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Impact: 10 Women Gauntlet Match 11/11/14[/B]", "S1Crl4RWReo", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]NWA: Harley Race vs Andre the Giant Houston 1/7/1979[/B]", "7_kU_7LsdF8", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]Tessa Blanchard vs KC Spinelli[/B]", "W-sP2Ls4plk", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Bellatrix Female Warriors: 5 Woman Tag Elimination[/B]", "Kkat3O89OSI", 801, "WOMEN", art+'waw.jpg', fanart),
        ("[B]ROH #1 Contender Gauntlet Match at Field of Honor 2015[/B]", "1QX-g28k-5I", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Hikaru Shida Vs Kaho Kobayashi 2017[/B]", "mKOpkIvakYU", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Impact Mr Anderson vs The Great Muta: USA vs The World[/B]", "MsVVI5zVDkg", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]TNT Extreme Wrestling: Pac vs Pentagon Jr 2019[/B]", "92lydmGMuyk", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]ICW: Joey Janela vs Freshly Squeezed Orange Cassidy 5/18/2019[/B]", "L2H7Dju_CR4", 801, "MISC", art+'misc.jpg', fanart),
        ("[B]EVE: Piper Niven vs Sierra Loxton[/B]", "F7sWnMaSDA8", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]Smash Wrestling: 3 Hour Gauntlet Match 2015[/B]", "BkXdUpsYomg", 801, "MISC", art+'smash.jpg', fanart),
        ("[B]Impact: Great Muta & TAJIRI vs James Storm & Sanada Bound for Glory 2014[/B]", "4TeW7t3qK8Y", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Defiant: 30 Man Rumble For WCPW Title No Regrets 2017[/B]", "Kgtf9xO2xUc", 801, "MISC", art+'defiant.jpg', fanart),
        ("[B]Defiant: Ricochet & Tessa Vs Will Ospreay & Bea 2017[/B]", "QkcxSFmz6CM", 801, "MISC", art+'defiant.jpg', fanart),
        ("[B]Impact: Tessa Blanchard vs Taya Valkyrie: STREET FIGHT 2/15/2019[/B]", "eYpaFlk7lPs", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]WWE: Roman Reigns vs Samoa Joe Backlash 2018[/B]", "741Pd7vdmX0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Las Mejores Luchas en Rey De Reyes 2018-2019[/B]", "w0BixgDtLnI", 801, "LUCHA", art+'lucha.jpg', fanart),
        ("[B]WWE: Sasha Banks-Bayley-Alicia Fox vs Charlotte - Dana Brooke - Nia Jax[/B]", "90lSXe4znmA", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]Stardom: Io Shirai vs Momo Watanabe May-23-2018[/B]", "HzLm2yezCKo", 801, "WOMEN", art+'stardom.jpg', fanart),
        ("[B]CHIKARA: Princess KimberLee vs. Heidi Lovelace[/B]", "4xozXN60MBI", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]CHIKARA: Mickie James vs. Princess KimberLee 2016[/B]", "x0AQqyFCakQ", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]RPW: Tessa Blanchard vs Britt Baker 9/16/17[/B]", "K5VQyaVV6Vg", 801, "WOMEN", art+'rpw.jpg', fanart),
        ("[B]Impact: Bobby Lashley vs EC3 IW 12/1/2016[/B]", "JS2rruRK7no", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Kana(Asuka) & Arisa Nakajima vs Syuri & Hikaru Shida[/B]", "ZeRyxx8nTRo", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Impact: Brooke, Tara & Velvet vs Winter, Angelina & Madison[/B]", "SFmyVOtdCgg", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Impact: Knockouts Santas Workshop Street Fight[/B]", "YF59I89z1UE", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Womens Wrestling: Hikaru Shida vs. Athena SHIMMER 66 (2014)[/B]", "T-g24zd3ggc", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]ROW 20-Man No Limits Rumble Match[/B]", "ngsQ_JKbOUc", 801, "ROW", art+'row.jpg', fanart),
        ("[B]Smash Wrestling: Rush, Bale, Perez, Kraven, Malone vs LeRae, Scott, Bomb, Blake, ? 2015[/B]", "MYfESnsPDdo", 801, "WOMEN", art+'smash.jpg', fanart),
        ("[B]Smash Wrestling: Rosemary (Courtney Rush) vs Jessicka Havok 2016[/B]", "gRgAOaXSrdo", 801, "WOMEN", art+'smash.jpg', fanart),
        ("[B]Smash Wrestling: Kimber Lee vs Courtney Rush 2016[/B]", "1ZjJK19RPvE", 801, "WOMEN", art+'smash.jpg', fanart),
        ("[B]Smash Wrestling: Courtney Rush vs KC Spinelli 2016[/B]", "WTrDIjd2FnU", 801, "WOMEN", art+'smash.jpg', fanart),
        ("[B]Smash: Leah Vaughan vs Cherry Bomb vs Courtney Rush 2016[/B]", "GN0BCN_-M6I", 801, "WOMEN", art+'smash.jpg', fanart),
        ("[B]Smash Wrestling: 3 Hour Gauntlet Match 2015[/B]", "BkXdUpsYomg", 801, "MISC", art+'smash.jpg', fanart),
        ("[B]Maria Manic vs Penelope Ford: Hybrid 10/28/16[/B]", "Tq7nSl4rL0I", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Thunder Rosa vs Alex Gracia: Ladies Night Out Underground 2019[/B]", "v_WbtfmSF14", 801, "WOMEN, ROW", art+'row.jpg', fanart),
        ("[B]Gail Kim vs ODB vs Brooke Tessmacher: Bound For Glory 2013[/B]", "XAykhreHYT4", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Women of Honor: Sumie Sakai vs Karen Q 2017[/B]", "rR0kaDxPc88", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Women of Honor: Deonna Purrazzo vs Karen Q No DQ 2018[/B]", "4zVw3apuZjE", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Tenille Dashwood & Mandy Leon vs Stacy Shadows & Kelly Klein 2018[/B]", "x-jABzaKrik", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Women of Honor: Sumie Sakai vs Hana Kimura 2018[/B]", "TvrV1jF5G-I", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Tenille Dashwood, Jenny Rose & Stella Grey vs Riley Shepherd, Ashley Vox & Kris Stadtlander[/B]", "uKsviqArnXQ", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Women of Honor: Mandy Leon vs Taeler Hendrix NO DQ 2016[/B]", "uIDBmXk0c8E", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Women of Honor Wednesday: Hania VS Mandy Leon 2016[/B]", "2aoK1oF1eRg", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Women of Honor: Thunder Rosa and Kelly Klein vs Tenille Dashwood and Sumie Sakai[/B]", "r3_QF9OI6tk", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]Women of Honor Wednesday: 6 Woman Tag Team Match 2016[/B]", "PK8Wr-reyNw", 801, "ROH, WOMEN", art+'roh.jpg', fanart),
        ("[B]AEW Casino Battle Royale: AEW All Out 2019[/B]", "4gDiUIVrups", 801, "AEW, WOMEN", art+'aew.jpg', fanart),
        ("[B]Sabotage: Angel Blue vs Leva Bates at Sabotage Wrestling 8/25/2018[/B]", "C7Z9EmCLjhM", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]EVE Kay Lee Ray VS Dash Chisako[/B]", "ZiuTyTNzxxY", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]Queens Of Combat: Taeler Hendrix VS Allysin Kay[/B]", "SK8xJGmORag", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]TMN Mercedes Martinez vs Rain 2010[/B]", "HJ47RMcBLZ0", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]PCW Ultra: Penta El Zero M vs. Johnny ULTRA 2017[/B]", "xJOhkf5TgjA", 801, "PCW, Misc", art+'pcw.jpg', fanart),
        ("[B]Prestige Wrestling: Jordynne Grace vs Priscilla Kelly[/B]", "hKwROMNmfy8", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]The Crash: Young Bucks vs Lucha Brothers 5/5/2017[/B]", "FsqEs6P-1uw", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]AEW Jon Moxley & Pac vs Kenny Omega & Hangman Adam Page[/B]", "zqTXASQshRA", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Jurassic Express vs Peter Avalon & Brandon Cutler[/B]", "tLghaP8WPj4", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]Impact: Mickie James vs Serena 2013[/B]", "zeKYL6KDX3Y", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Will Ospreay vs Drew Galloway: WCPW Exit Wounds 2017[/B]", "AR-QHXaAaJU", 801, "MISC", art+'defiant.jpg', fanart),
        ("[B]Will Ospreay vs. Amazing Red SUPER J-CUP 2019[/B]", "8yKk4ixzxp0", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Kevin Steen VS Tommy Dreamer: ECW Rules Match 01/28/2012[/B]", "A-CCsFboTEw", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]Matt Hardy VS MVP (Crossfire Wrestling 2012)[/B]", "W8HlSDMwiRo", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Penelope Ford vs Taya Valkyrie (Street Fight)[/B]", "sWZ-QoJ9ql8", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]WWN Freebie: Matt Riddle vs. Keith Lee I (EVOLVE 87)[/B]", "VQjl4zSpE6A", 801, "MISC, WWN", art+'wwn.jpg', fanart),
        ("[B]FSW: Brian Cage vs Killer Kross 2015[/B]", "mBncm79ebD0", 801, "MISC", art+'misc2.jpg', fanart),
        ("[B]Ricochet vs Brian Cage vs Austin Aries: International Assault 2017[/B]", "2mNVo3Z06x0", 801, "MISC", art+'misc2.jpg', fanart),
        ("[B]WrestleCircus: Shane Strickland vs Brian Cage 10/21/17[/B]", "rj6sYZYw_E8", 801, "MISC, CIRCUS", art+'circus.jpg', fanart),
        ("[B]OTT Sean Guinness & Jordan Devlin Vs Keith Lee & Shane Strickland [/B]", "UZz_8WpGqPg", 801, "MISC", art+'ott.jpg', fanart),
        ("[B]OTT Matt Riddle Vs Will Ospreay: ScrapperMania 4[/B]", "vB-1AcF60mM", 801, "MISC", art+'ott.jpg', fanart),
        ("[B]Thunder Rosa vs Alex Garcia vs Myka: Triple Threat[/B]", "GYwBiuoGz3s", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Thunder Rosa vs Rok-C: Womens Wrestling[/B]", "-jT4O3yEhYQ", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Kylie Rae vs Rok-C: Womens Wrestling[/B]", "DJMq2nIJ-70", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Su Yung vs Rok-C: Hardcore Womens Match[/B]", "ZRNIkmLc8Xg", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Abilene Texas at The Forge: Hyan vs Rok-C 2019[/B]", "xKf8az7Sjv4", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]SPW: Tenille Dashwood vs Bea Priestley in New Zealand[/B]", "13rkThf1yyE", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Santana Garrett vs Deonna Purrazzo 2016[/B]", "QoqjWMeYjpE", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Santana Garrett vs Tessa Blanchard[/B]", "kji8G_XkW6Y", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Tessa Blanchard vs Chelsea Green WrestleCircus 3/24/18[/B]", "mJPM40COTAc", 801, "WOMEN, CIRCUS", art+'circus.jpg', fanart),    
        ("[B]Santana Garrett vs Kairi Hojo World of Stardom 4/29/16[/B]", "IY3v2TojzAA", 801, "WOMEN", art+'stardom.jpg', fanart),    
        ("[B]Io Shirai vs Alpha Female 3/29/13 World of Stardom[/B]", "ugqkeSrVp1s", 801, "WOMEN", art+'stardom.jpg', fanart),    
        ("[B]Asuka (Kana) vs Hikaru Shida[/B]", "1A82RfeUHFc", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Io Shirai vs Toni Storm World of Stardom[/B]", "IRBPFBrAGbo", 801, "WOMEN", art+'stardom.jpg', fanart),    
        ("[B]Tessa Blanchard vs Britt Baker Remix Pro Fury Championship 9/6/17[/B]", "FAMoTCNbGBM", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Io Shirai vs Kairi Hojo 3/29/15 World of Stardom[/B]", "0YV-MO7ZJiY", 801, "WOMEN", art+'stardom.jpg', fanart),    
        ("[B]Queens of Combat 8: Su Yung vs Kimber Lee[/B]", "YFGXsYDvlhM", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]NorthEast Wrestling: Hardy Boys VS Young Bucks 2014[/B]", "PyhgGzFfUEg", 801, "MISC, NEW", art+'new.jpg', fanart),    
        ("[B]QOC Supercon: Chelsea Green VS Rachael Ellering[/B]", "8XCZTZKjbPo", 801, "WOMEN", art+'women.jpg', fanart),    
        ("[B]Diamante VS Kris Stadtlander: QOC 27: Heir To The Throne[/B]", "J1Lqn1wib5o", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Impact Drew Galloway vs Bobbie Lashley[/B]", "l4XZ_Q5-UdM", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Knockouts Battle Royal: Sacrifice 2008[/B]", "QoLv7Tfhs1U", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]ROH Young Bucks vs Hardy Boyz (Ladder Match)[/B]", "ygCmwh5kL58", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Kevin Steen vs Silas Young (No DQ Match) 2014[/B]", "2r7OV3NWMGc", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]WILL OSPREAY VS BANDIDO (Wrestlecon 2019)[/B]", "mAcRO89Aw30", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Wrestle Circus: Tessa Blanchard vs Rachel Ellering 2017[/B]", "_UShzJ892Gw", 801, "WOMEN, CIRCUS", art+'circus.jpg', fanart),
        ("[B]BCP Wrestling: Tessa Blanchard vs Mia Kim[/B]", "gLP_59gy27o", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]OTT Marty Scurll Vs The Bro Matt Riddle[/B]", "9p7ShOSnQWE", 801, "MISC", art+'ott.jpg', fanart),
        ("[B]ALL IN: Kenny Omega Vs Pentagon Jr 2018[/B]", "w5D9wjbrAkI", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]OTT David Starr Vs Jordan Devlin: FifthYearAnniversary 2019[/B]", "lurEXADlboY", 801, "MISC", art+'ott.jpg', fanart),
        ("[B]Impact Beautiful People vs ODB, Gail Kim (May 1, 2008)[/B]", "0QCfXHH0ZSo", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]WWN Ibushi, Gargano & TJP vs. Ospreay, End & Scurll: Supershow 2016[/B]", "4PKTYt8zhVI", 801, "MISC, WWN", art+'wwn.jpg', fanart),
        ("[B]Will Ospreay Vs Walter from Over The Top Wrestling[/B]", "FPTemrD73-w", 801, "MISC, OTT", art+'ott.jpg', fanart),
        ("[B]Impact Bound For Glory 2007 - Knockouts Gauntlet Match[/B]", "DVEfQn0ou2Y", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Thunder Rosa vs Shotzi Blackheart: Victoria, Texas 01/07/2017[/B]", "CrH2vriH22U", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]PPW Second Annual Kyle Cup Battle Royale: 1/17/20[/B]", "YaGYdDNcwUo", 801, "MISC", art+'misc.jpg', fanart),
        ("[B]PPW First Annual Kyle Cup Battle Royale: 11/16/18[/B]", "WftCeXFNY6Q", 801, "MISC", art+'misc.jpg', fanart),
        ("[B]WOW Mickie James v Angelina Love 9/21/13[/B]", "VgyUdR-7jgs", 801, "WOMEN, WOW", art+'wow.jpg', fanart),
        ("[B]WOW Penelope Ford vs Nikki Addams 10/17/17[/B]", "v6S0tKjSstE", 801, "WOMEN, WOW", art+'wow.jpg', fanart),
        ("[B]WOW Nyla Rose vs Nikki Addams: Steel Cage 12/1/18[/B]", "iRHiJq8jPlU", 801, "WOMEN, WOW", art+'wow.jpg', fanart),
        ("[B]Championship Wrestling: Heather Monroe v Simone Sherie[/B]", "1UWfLSqOYkw", 801, "WOMEN", art+'champ.jpg', fanart),
        ("[B]WWE Ronda Rousey vs Nikki Bella: Raw Womens Championship 2018[/B]", "-7sYq2eo8dc", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]Zoe Lucas vs. Big Swole Womens Wrestling from The Summit[/B]", "ycbyxLp__KE", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Barbi Hayden vs Miranda Alize: All-Star, Womens Wrestling 2018[/B]", "sLMU_gax6fk", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Thunder Rosa vs Shotzi Blackheart: Phoenix Pro Wrestling 6/23/17[/B]", "kmkZM8aYcJw", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Kris Wolf vs Shotzi Blackheart at Hey Ladies 2[/B]", "lQohTkaRCkM", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Thunder Rosa vs Penelope Ford at Hey Ladies 2[/B]", "HWjEzWaaUqg", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Tessa Blanchard vs. Mercedes Martinez: Longest Womens Match of All Time 2018[/B]", "apoJgbkKRb0", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]SHIMMER Title Tournament Final: Lacey vs. Sara Del Rey 2007[/B]", "hjTJXQ39wlM", 801, "WOMEN", art+'shimmer.jpg', fanart),
        ("[B]Shimmer MsChif and Amazing Kong: April 7, 2007[/B]", "lb77XOAHsq8", 801, "WOMEN", art+'shimmer.jpg', fanart),
        ("[B]Athena vs Mercedes Martinez: SHIMMER 43, 44, 45[/B]", "NRF7i5Wdus0", 801, "WOMEN", art+'shimmer.jpg', fanart),
        ("[B]Del Rey & Eagles & Haze & Nakagawa vs. Serena & Melissa & Hamada & Kurihara[/B]", "LGPv_j8W7bg", 801, "WOMEN", art+'women.jpg', fanart),
        ("[B]Deonna Purrazzo vs. Madison Eagles: SHIMMER 101 Submission Match[/B]", "jXhGhAolY28", 801, "WOMEN", art+'shimmer.jpg', fanart),
        ("[B]Shimmer Mercedes Martinez vs. Sara Del Rey: Nov. 6, 2005[/B]", "Ws1DjKOGEvs", 801, "WOMEN", art+'shimmer.jpg', fanart),
        ("[B]Hikaru Shida vs. Athena: SHIMMER 66[/B]", "T-g24zd3ggc", 801, "WOMEN", art+'shimmer.jpg', fanart),
        ("[B]Christopher Daniels vs Mark Haskins: Tuesday Night Graps 3/20/2018[/B]", "CAkJY8vno-8", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]Mark Haskins vs Austin Aries: International Battle Royale 2018[/B]", "g1lxQMlRZtw", 801, "MISC", art+'misc2.jpg', fanart),
        ("[B]Jimmy Havoc vs Bad Bones UK Summer Bonus: 8/9/2015[/B]", "hYRZpP8BnM0", 801, "MISC", art+'misc.jpg', fanart),
        ("[B]Will Ospreay vs Cody UK SuperShow 5: 12/18/2016[/B]", "Ry_xwNyi6Wo", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]AEW Jon Moxley vs Joey Janela Non-Sanctioned Match[/B]", "783qpbZcpBo", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Michael Nakazawa vs Brandon Cutler: 5/26/20[/B]", "z0pri6rBCPM", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Luther vs Jimmy Havoc: AEW DARK - 3/12/20[/B]", "IdSYv9xZsWU", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW SCU VS Shawn Spears & Robert Anthony: 3/25/20[/B]", "R0a9mCUbILE", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Stu Grayson vs Christopher Daniels: 3/11/20 SALT LAKE CITY[/B]", "8SnFMdSzxkU", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Jurassic Express vs Kip Sabian & Peter Avalon 3/4/20[/B]", "suwP-tVckeE", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Sonny Kiss & Brandon Cutler vs Private Party 3/4/20[/B]", "FyqDxXOtVVQ", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Shawn Spears & Brandon Cutler vs Private Party 2/26/20[/B]", "RbwBgt6o2w0", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Yuka Sakazaki & Riho vs Penelope Ford & Britt Baker: 2/29/20[/B]", "TY3_2mXxisU", 801, "AEW, WOMEN", art+'aew.jpg', fanart),
        ("[B]AEW Jimmy Havoc vs Marko Stunt: 2/19/20[/B]", "wNuGyqExl7o", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Shawn Spears & Peter Avalon vs Dustin Rhodes & QT Marshall: 2/19/20[/B]", "h-vjh-gasE0", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Kip Sabian vs Joey Janela: 2/19/20[/B]", "Xzd6bpQ-qCU", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW The Young Bucks vs QT Marshall & Peter Avalon: 2/12/20[/B]", "wyYB1uflUWs", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW The Hybrid 2 vs Best Friends: 2/12/20[/B]", "sqRDCX_ZwsI", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Dark Order vs Jurassic Express: 2/5/20[/B]", "5dVh2v3EiOo", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Sonny Kiss vs Jimmy Havoc: 2/5/20[/B]", "axMvkBEUHwg", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Best Fiends vs Shawn Spears & Mystery Partner: 1/29/20[/B]", "RYZsNpTWa0I", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Mel vs Hikaru Shida: 1/29/20[/B]", "1AaNd7Alfi0", 801, "AEW, WOMEN", art+'aew.jpg', fanart),
        ("[B]AEW Jimmy Havoc & Kip Sabian vs Musa & Lee Johnson: 5/19/20[/B]", "G2ch68-3P5Q", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Joey Janela vs Rey Fenix: Rock N Rager Bonus Match[/B]", "9uMo6CEbSoc", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Cody Rhodes vs Darby Allin 12/2020[/B]", "24QTLzdQXdw", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Riho vs Nyla Rose vs Yuka Sakazaki from AEWs Fyter Fest[/B]", "TSV5FG5313Y", 801, "AEW, WOMEN", art+'aew.jpg', fanart),
        ("[B]AEW Christopher Daniels vs CIMA from AEWs Fyter Fest[/B]", "tfs6AAijvyQ", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]AEW Private Party vs SCU vs Best Friends: Fyter Fest Buy In[/B]", "VYgHDBhGeuM", 801, "AEW", art+'aew.jpg', fanart),
        ("[B]TMN Jordynne Grace vs Su Yung - Ladies Night Out[/B]", "BDaOjbKarAk", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Rok-C vs Heather Monroe - Ladies Night Out 9[/B]", "_twbXda4TWk", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Priscilla Kelly vs Heather Monroe: Queens of the Ring 2[/B]", "qXejNiXuiV0", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Rok-C - Queens of the Ring 2[/B]", "LE3CmEUJZOI", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Mercedes Martinez vs Thunder Rosa - Queens of the Ring[/B]", "NSLVBfGLbK8", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Alex Gracia vs Heather Monroe - Queens of the Ring[/B]", "K82wZZqRnVI", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Thunder Rosa vs Mercedes Martinez (iPPV Version) Queens of the Ring[/B]", "R_T-Msh_BHM", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Diamante - Ladies Night Out 7[/B]", "AJQ0O96GUhc", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Thunder Rosa vs Raychell Rose - Ladies Night Out 7[/B]", "AJoDi6tq6Z4", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Mia Yim vs Serena Deeb: Bombshell Ladies of Wrestling[/B]", "8Kqfpa0ZS3g", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Su Yung vs Harlow OHara - Last Woman Standing[/B]", "InbSom1i6yo", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Jessicka Havok vs Su Yung: Battle Club Pro 2018[/B]", "fivlq3pStB4", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Kiera Hogan - Ladies Night Out II[/B]", "deD6D0RbweQ", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Thunder Rosa: Ladies Night Out 4 - Nov 2018[/B]", "T8ruIxQtigw", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN All Women Gauntlet: Su Yung, Jordynne Grace, Maria Manic, Leva Bates, Harlow OHara[/B]", "dBSp0hrKtyA", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Taya Valkyrie vs Thunder Rosa: Ladies Night Out 5 - Feb 23, 2019[/B]", "CYvzgXzZ-0c", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Jazz - Falls Count Anywhere - Ladies Night Out 5[/B]", "DmeVrd-S6_A", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Kylie Rae vs Raychell Rose: Ladies Night Out 6[/B]", "b_bGE4SpIwo", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Su Yung vs Laynie Luck - Ladies Night Out 6[/B]", "qgkSGgYimxM", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Kylie Rae vs Harlow OHara - Battle Club Pro[/B]", "Y-OV2jgLZ34", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Heather Monroe vs KC Spinelli - We Are One[/B]", "nmSGirhT7WA", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Mercedes Martinez vs Hyan - Ladies Night Out 7[/B]", "Mq59f2x-ABw", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Nyla Rose vs Saraya Knight: Women of Warriors VII[/B]", "mAsFS--t9b0", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Su Yung vs Hyan - No DQ Brawl - Ladies Night Out 4 - Nov 2018[/B]", "nRWqZWDo5AQ", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Kiera Hogan (Steel Cage Match) Ladies Night Out 3[/B]", "rrRDPCZgHlI", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Jordynne Grace vs Hyan: Ladies Night Out 3[/B]", "ZEXFeEzfLYc", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Thunder Rosa vs Holidead - Ladies Night Out 8[/B]", "aTfkx0c6Ajg", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Miranda Alize - Ladies Night Out 8[/B]", "uGdizgeSdrs", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Ivelisse vs Kiera Hogan vs Miranda Alize vs Diamante: Ladies Night Out[/B]", "hITQoFVj1Lk", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Priscilla Kelly vs Heather Monroe - Queens of the Ring 2[/B]", "qXejNiXuiV0", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Rok-C vs Heather Monroe - Ladies Night Out 9[/B]", "_twbXda4TWk", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Jordynne Grace vs Su Yung - Ladies Night Out 9[/B]", "BDaOjbKarAk", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Mia Yim vs Christina Von Eerie: Bombshell Ladies of Wrestling[/B]", "-uVxjK5K9nM", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]TMN Mickie James vs Mercedes Martinez[/B]", "cdm-OUbU_1g", 801, "TMN, WOMEN", art+'tmn.jpg', fanart),
        ("[B]ROH 60 Minute Match Taven VS Lethal 2019[/B]", "-EuoGmfEls0", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]WrestleCircus: Team Jervis vs Team Austin with LEVATAKER![/B]", "oP3oRm4OXPs", 801, "WOMEN, CIRCUS", art+'circus.jpg', fanart),
        ("[B]LevaTaker (Leva Bates) Vs. Dirty Andy Dalton 2018[/B]", "uqigJrVyE-s", 801, "MISC, WOMEN", art+'women.jpg', fanart),
        ("[B]WWE The Undertaker vs. Kane: Inferno Match 1998[/B]", "MpAE-1KX1Io", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Shayna Baszler vs. Io Shirai: NXT TakeOver XXV[/B]", "OcOGmapNQJ4", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE Undertaker vs. Edge: Backlash 2008[/B]", "IKms3_hCEd8", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Stone Cold Steve Austin vs Undertaker: Backlash 2002[/B]", "380Ql-7f8Co", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Rob Van Dam vs Eddie Guerrero: Backlash 2002[/B]", "r2jvG3QaboA", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Kane vs. Bray Wyatt: Backlash 2016[/B]", "BMMHhAMV08A", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]EVE Womens Steel Cage War Games 2020[/B]", "H-_nTrzIXJY", 801, "WOMEN, EVE", art+'eve.jpg', fanart),
        ("[B]WWE John Cena vs. Batista: Over the Limit 2010[/B]", "Vg5bGdFE7Q8", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE D-Generation X vs Rated-RKO: Cyber Sunday 2006[/B]", "-1jGMS0slt8", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Randy Orton vs Bray Wyatt: Payback 2017[/B]", "brYV8_X_sZ0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE John Cena vs The Miz: Over the Limit 2011[/B]", "FUtOaczGmUY", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Womens Ladder Match: Money in the Bank 2019[/B]", "nOnkSe1WMWo", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE John Cena vs Edge vs Randy Orton vs Sheamus: 2010[/B]", "bW947IyCCU0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Mens Ladder Match: Money in the Bank 2019[/B]", "7p-TrKRvpSc", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Seth Rollins vs. AJ Styles: Money in the Bank 2019[/B]", "bS8lD2hFc4s", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Undertaker vs. Edge : Judgment Day 2008[/B]", "aJni9SyJ1SQ", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]El Phantasmo vs Brian Cage: ECCW Championship (7/16/16)[/B]", "MM9veiKSpfg", 801, "MISC", art+'misc3.jpg', fanart),
        ("[B]EVE Meiko Satomura vs Kay Lee Ray 5/5/2018 [/B]", "19qrHO_7fmo", 801, "WOMEN, EVE", art+'eve.jpg', fanart),
        ("[B]EVE Su Yung vs Session Goth[/B]", "SDqA7ZCtJmg", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE FLASHBACK! Riho [AEW] vs Viper [NXT UK] vs Sammii Jayne [/B]", "CRL3kgaYC7I", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Jordynne Grace vs Laura Di Matteo: WrestleQueendom 2[/B]", "3niwjtzHoQs", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Kay Lee Ray vs Sammii Jayne - Title Match[/B]", "zpRx28I-WEc", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Rhia O'Reilly vs Sammii Jayne[/B]", "NADqddlLPnU", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE WWE Diva Paige FKA Britani Knight vs Portugals Perfect Athlete Shanna[/B]", "bg5riUqbFc8", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Meiko Satomura vs Kay Lee Ray 2018[/B]", "19qrHO_7fmo", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE JAMIE HAYTER vs ROXXY[/B]", "z7uSttlPC34", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Charlie Morgan vs Sammii Jayne[/B]", "MhjoVOtqHPQ", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE AJA KONG [Legend] vs VIPER PIPER NIVEN [NXT UK][/B]", "gZvla79stqI", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Sisters Collide: Toni Storm vs Jetta Storm[/B]", "QH1syjYq5Vw", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]EVE Jazz vs Rhia O Reilly[/B]", "3Rv_NRYVCbc", 801, "EVE, WOMEN", art+'eve.jpg', fanart),
        ("[B]NWA Allysin Kay vs. Heather Monroe: NWA Womens World Championship 2019[/B]", "zqslk2B3kZA", 801, "NWA, WOMEN", art+'nwa.jpg', fanart),
        ("[B]NWA Nick Aldis vs. Tim Storm 3 (2019)[/B]", "NvcJLkI2d64", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Nick Aldis vs. Cody Rhodes 2: NWA 70[/B]", "VBxINBVhToA", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Nick Aldis vs. David Starr: NWA Worlds Championship 2018[/B]", "4wvSGIkcgWs", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Nick Aldis vs. Colt Cabana: NWA Worlds Title 2018[/B]", "4yzWEYzwucE", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Cody Rhodes vs. Willie Mack: NWA Worlds Championship 2018[/B]", "UwkiiSyJoME", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Nick Aldis vs. Jake Hager: NWA Worlds Heavyweight Championship 2018[/B]", "-k_D4KezEY0", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Nick Aldis vs. PJ Black: NWA Worlds Championship 2019[/B]", "uI6gA8BD-9M", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Harley Race vs. Terry Funk: NWA Worlds Heavyweight Championship[/B]", "a0n7xf8hRZo", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]NWA Colt Cabana vs. James Storm: NWA National Championship[/B]", "-6nYMKIW4jg", 801, "NWA", art+'nwa.jpg', fanart),
        ("[B]MLW Davey Boy Smith Jr. vs. Filthy Tom Lawlor[/B]", "ykUTCbyKy3s", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW Timothy Thatcher vs Low Ki[/B]", "-TQKYzvD-H4", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW Ross Von Erich vs Jacob Fatu[/B]", "S5NvL4OmuSQ", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW Matt Riddle vs. Shane Strickland: World Heavyweight Title [/B]", "vKraeLSYiR8", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW Funkin Army vs. Extreme Horsemen: War Games 2003[/B]", "ivNc8kOvATk", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW LA Park vs Sabu: MLW King of Kings 2002[/B]", "3PiyAz8VwHg", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW First-ever 40 Man Battle Riot[/B]", "k1j8A8GxvCw", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]MLW War Games Match featuring a 2-ring steel cage encounter[/B]", "Cik45m2CsVs", 801, "MLW", art+'mlw.jpg', fanart),
        ("[B]ROW Diamonds: Alex Gracia vs Hyan vs Raychell Rose vs Jenna Lynn vs Rok-C vs AQA[/B]", "I4ShdtOOvQM", 801, "ROW, WOMEN", art+'row.jpg', fanart),
        ("[B]ROW Diamonds: Hyan vs AQA - Steel Cage Match[/B]", "Q2w8R0iknPw", 801, "ROW, WOMEN", art+'row.jpg', fanart),
        ("[B]ROW Diamonds: Kylie Rae vs Hyan vs AQA[/B]", "1Pk_Ya_xZq8", 801, "ROW, WOMEN", art+'row.jpg', fanart),
        ("[B]ROW Will Allday vs Ayden Cristiano: Rise to Wrestling Royalty[/B]", "r52mXVNK5xY", 801, "ROW", art+'row.jpg', fanart),
        ("[B]ROW Zack Mason vs Brenden Steen: Rise to Wrestling Royalty[/B]", "SgFE2NOhSms", 801, "ROW", art+'row.jpg', fanart),
        ("[B]ROW Ryan Davidson vs Bryan Keith: Rise to Wrestling Royalty[/B]", "LZk_mw9Odr8", 801, "ROW", art+'row.jpg', fanart),
        ("[B]ROW Gino vs Rex Andrews: Rise to Wrestling Royalty[/B]", "sY05NOWegC4", 801, "ROW", art+'row.jpg', fanart),
        ("[B]WWE Triple H vs Randy Orton: Judgment Day 2008[/B]", "LUsBSqsVZYo", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]NXT Sasha Banks vs Becky Lynch: NXT TakeOver: Unstoppable[/B]", "vBhKvdOX0nM", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]NXT Johnny Gargano vs Adam Cole: NXT TakeOver: New York[/B]", "vSa_f9sQED0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Rey Mysterio vs R-Truth: Over the Limit 2011[/B]", "QVXfqL3acck", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2011[/B]", "6aqhLc7_e9o", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2012[/B]", "C7BgSyGREv8", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2013[/B]", "7BMN88v0zMA", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2014[/B]", "PXNZ0cr1KjY", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2015[/B]", "ZWwg1m8HL8A", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2017[/B]", "IXql4ayoMH0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2018[/B]", "m-bkIJJ3sa0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE World Heavyweight Title Contract: Money in the Bank 2019[/B]", "7p-TrKRvpSc", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Womens Ladder Match: WWE Money in the Bank 2018[/B]", "Q3MnViawh28", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE Roman Reigns vs. Seth Rollins: Money in the Bank 2016[/B]", "yslOPpLe4Eg", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE John Cena vs CM Punk: Summerslam 2011[/B]", "cN0Kg-TmFYs", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Charlotte Flair vs Natalya: NXT TakeOver[/B]", "_bZlm6NLxFU", 801, "WWE, WOMEN", art+'wwe6.jpg', fanart),
        ("[B]WWE Bret Hart vs Hakushi: WWE In Your House 1995[/B]", "ZebcROKvQqs", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Randy Orton vs. Edge: WWE Vengeance 2004[/B]", "y0P6Uh82Sxg", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Christian vs Randy Orton: SmackDown, May 6, 2011[/B]", "0aASbz_GF9s", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE North American Title Ladder Match: NXT TakeOver New Orleans[/B]", "mt5VS1RjRbE", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Jinder Mahal vs Randy Orton: Money in the Bank 2017[/B]", "FXMpORlDxe0", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE AJ Styles vs Shinsuke Nakamura: Last Man Standing Match[/B]", "rl7D0X6zICU", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Triple H vs John Cena: Night of Champions 2008[/B]", "pAAYl1GfYCA", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE AJ Styles vs Shinsuke Nakamura: Money in the Bank[/B]", "rl7D0X6zICU", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]WWE Roman Reigns vs AJ Styles: WWE Payback 2016[/B]", "q4dYpg8mo94", 801, "WWE", art+'wwe6.jpg', fanart),
        ("[B]ROH Dragon Lee vs Will Ospreay: Manhattan Mayhem 2017[/B]", "BhrLxwObkgc", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Paul London vs Bryan Danielson: Legendary 2-out-of-3 Falls[/B]", "0uUHZdNs2To", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Marty Scurll vs Dalton Castle: Reach For The Sky Liverpool[/B]", "y7UTWVQesYQ", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH 1st Main Event: Bryan Danielson vs Low Ki vs Christopher Daniels[/B]", "m0W6eb5mOh0", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Dalton Castle vs Silas Young: FIGHT WITHOUT HONOR 2016[/B]", "jujsERvLR0w", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Adam Cole vs Marty Scurll: Supercard of Honor XI[/B]", "5oOlpDfzpts", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH CM Punk vs Raven: VIOLENT Clockwork Orange House of Fun Match[/B]", "iAzKzUe4pek", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Kingdom vs Bullet Club: ROH/NJPW War of the Worlds[/B]", "8ywQUKgTB4Q", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Jay Briscoe vs Samoa Joe: Supercard of Honor IX[/B]", "QCyCclBs-fE", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH PCO vs Mark Briscoe: Bound By Honor 2019[/B]", "DH0xtAjJ1EE", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Kenny Omega vs Austin Aries: Buffalo Stampede 2010[/B]", "D9BN0In4duM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Young Bucks vs Kevin Steen & El Generico: Contention 2009[/B]", "SsCRfdQctTQ", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Chris Hero vs Adam Cole: ROH World Championship[/B]", "mRGuUxxy5oM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH CM Punk vs Raven: INSANE Dog Collar Match 2003[/B]", "KyQnrHwYpDM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Brodie Lee & Jimmy Jacobs vs Tyler Black & Necro Butcher[/B]", "G8qbBOwg-PI", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH CM Punk vs AJ Styles: Pure Championship Finals ROH 2nd Anniversary[/B]", "TNC_XjsyuBc", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Kenny Omega vs Bryan Danielson vs Tyler Black: Bound By Hate 2008[/B]", "qswfd3epU0k", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Tyler Black vs Kevin Steen: Salvation 2010[/B]", "ZOf_f6J-m2M", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH RUSH vs Tracy Williams: Road to G1 Supercard 2019[/B]", "7d09dOs5rTY", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Kevin Steen & El Generico vs Motor City Machine Guns: Death Before Dishonor VI[/B]", "IOXQ6U5n4Qs", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Chris Hero vs Bryan Danielson: Throwback Thursday[/B]", "fld2-qLlHfw", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Flip Gordon vs Bandido vs PJ Black vs Caristico 2019[/B]", "fobjLw1Z34Y", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Tommaso Ciampa vs Jay Lethal: Supercard of Honor VIII[/B]", "mslrC3KENHk", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH RUSH & Bandido face off at ROH 17th Anniversary[/B]", "u3-ieQGetmU", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Mark Haskins vs Adam Page: Honor Re-United Tour 2018[/B]", "fh7rgmSTinY", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH KENTA vs Bryan Danielson vs Samoa Joe 2006[/B]", "DGnYfDz8VVs", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH AJ Styles vs Adam Cole: All-Star Extravaganza VI 2014[/B]", "P5fJkVAfLtg", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Matt Taven vs Jay Lethal: Field of Honor 2014[/B]", "w6WsYWh3htE", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Kevin Steen vs Eddie Edwards vs Roderick Strong vs Michael Elgin[/B]", "ueg59O6pSsE", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH The Briscoes vs Samoa Joe & Homicide: Motor City Madness 2006[/B]", "H3ZnAlGRLes", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Flip Gordon vs Nick Aldis for the NWA Worlds Heavyweight Championship[/B]", "OAesrx-6KPw", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Dalton Castle vs Jay Lethal vs Cody vs Matt Taven: ROH TV #357[/B]", "POSk3BY-lus", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Bryan Danielson vs KENTA: Glory By Honor V 2006 [/B]", "DOrl73UPrzY", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Marty Scurll vs Matt Taven vs Kenny King vs SANADA 2018[/B]", "omuv3oi8D70", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH The Kingdom take on The Briscoes in Tag Team Armageddon[/B]", "7dxQxc_Z1ks", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH CM Punk vs Samoa Joe vs Christopher Daniels vs Steve Corino 2003[/B]", "YryMr8ZMj60", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Bryan Danielson vs Austin Aries vs Colt Cabana vs Homicide vs Mark Briscoe vs Samoa Joe[/B]", "YgbdHdDSIc8", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Samoa Joe vs Low Ki: Fight Without Honor[/B]", "ni8x8rveuuM", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Christopher Daniels vs Kevin Steen: Throwback Thursday[/B]", "KcAajEcWGHU", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]ROH Bullet Club & Stephen Amell vs SCU & Flip Gordon[/B]", "WKMKYpPPf-Q", 801, "ROH", art+'roh.jpg', fanart),
        ("[B]Impact Eric Young vs Abyss: Monsters Ball Match TNA Rivals 2015[/B]", "jeMBNPg8w_4", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Eric Young, Tanahashi & More in 10-Way X-Division Battle 2008[/B]", "lSIhpLXYpyo", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Bobby Lashley vs MVP: No DQ World Title Match 2015[/B]", "cXHqfGcjvUE", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Rosemary vs Taya Valkyrie: DDemons Dance Match 2018[/B]", "A-LUPpY5U5w", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles clashes with Rhino at TNA Destination X 2007[/B]", "rArLTVXvL7w", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact First-Ever King of the Mountain Match: NWA-TNA PPV #97[/B]", "5r0Je11fzZY", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Dustin Rhodes vs Bobby Roode: Lockdown 2005[/B]", "56IyF72NkTs", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Tommy Dreamer: No DQ Match Sacrifice 2011[/B]", "ILHtzq8AMag", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Matt Hardy: TNA Victory Road 2011[/B]", "2j6jTGP4fbo", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Samoa Joe vs Booker T: TNA Hard Justice 2008[/B]", "fPV0vDirpjQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Rhino vs Christian: 8 Mile Street Fight BFG 2006[/B]", "jH1u4NfNWHU", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Ric Flair vs Mick Foley: Last Man Standing Before The Glory[/B]", "Gx1xvUqVuNU", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Sting: Bound For Glory 2009[/B]", "5JfLyWwEyLo", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Beer Money & Team 3D vs Main Event Mafia & British Invasion[/B]", "nMArESxjjNc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Jay Lethal vs Sonjay Dutt: Ladder of Love Match No Surrender 2008[/B]", "-Kv9XKZuPag", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Tessa Blanchard vs Sami Callihan: Unbreakable 2019[/B]", "EKRwali74S4", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Impact Samoa Joe vs Scott Steiner vs Kaz: Sacrifice 2008[/B]", "hJB-44FqeYs", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Jay Lethal: Slammiversary 2010[/B]", "LZ6NRb0CBbc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Rob Van Dam vs Tommy Dreamer: TNA Turning Point 2010[/B]", "BNHUoNqjfdQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Samoa Joe vs AJ Styles: TNA Sacrifice 2005[/B]", "EKNMGxmfL6M", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Jay Lethal vs Petey Williams: Destination X 2008[/B]", "GCxJeEHDzwc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Sami Callihan vs Jimmy Havoc: Barbed Wire Baseball Bat Death Match[/B]", "cA6lv9zFmAc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Rob Van Dam vs Sabu: The Last Stand 2010[/B]", "w5b9nVHCM4g", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Abyss vs Matt Hardy: Monsters Ball Hardcore Justice 4[/B]", "GDgw-qlNiYs", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Kurt Angle vs Sting: Bound for Glory 2007[/B]", "oZAVVT_dlCE", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Dusty Rhodes: NWA-TNA PPV #65[/B]", "54F9S_GfH0c", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Madison Rayne vs Mickie James: Genesis 2011[/B]", "5z5m8KdHd80", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Impact Raven vs Vampiro: NWA-TNA PPV #68[/B]", "SfbphNori-4", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Kurt Angle vs Jay Lethal: No Surrender 2007[/B]", "78_vWCGuXZw", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Gail Kim vs Awesome Kong: Final Resolution 2008[/B]", "IMKL-qZZTbE", 801, "TNA, WOMEN", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Booker T vs Christian Cage: Bound for Glory 2008[/B]", "a8vkSsVYJ9M", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Abyss & Tommy Dreamer vs Team 3D: Bound for Glory 2014[/B]", "aIQ1KFDLsKc", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Kurt Angle vs Matt Morgan: Bound For Glory 2009[/B]", "x7rfsjHl3dw", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Raven vs Rhino: Ravens Rules for the Championship[/B]", "GSf6uLPhLi4", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Matt Hardy vs Rob Van Dam: Against All Odds 2011[/B]", "7ByeN7VFbLI", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Samoa Joe & Sting vs Scott Steiner & Jeff Jarrett: Sacrifice 2006[/B]", "UpRgQcvhnFw", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Young Bucks vs Motor City Machine Guns: No Surrender 2010[/B]", "R83Ystt-OdQ", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Kurt Angle: Slammiversary XI[/B]", "yA4jBk3WQho", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Jeff Hardy vs Matt Hardy (I Quit): The Broken Saga Begins[/B]", "_rUxD-KnL5E", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Tommy Dreamer vs Bully Ray: Falls Count Anywhere[/B]", "7J58EPMbDAU", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact Young Bucks vs Bad Influence: Hardcore Justice 2013[/B]", "NU0WBrie2r0", 801, "TNA", art+'impact.jpg', fanart),
        ("[B]Impact AJ Styles vs Low-Ki: NWA-TNA PPV #5 - July 17, 2002[/B]", "8_Ws4CoGtt8", 801, "TNA", art+'impact.jpg', fanart),
]

#=====================================

class matchListing:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for name, url, zmode, genre, theImage, fanart in channellist:

            addIt=False
            if type is "All":
                icon=art+"match.jpg"
                addIt=True

            elif type is "1pw" and '1PW' in genre:
                icon=art+"1pw.jpg"
                addIt=True

            elif type is "aew" and 'AEW' in genre:
                icon=art+"aew.jpg"
                addIt=True

            elif type is "bwf" and 'BRONX' in genre:
                icon=art+"bwf.jpg"
                addIt=True

            elif type is "ccw" and 'CCW' in genre:
                icon=art+"cascade.jpg"
                addIt=True

            elif type is "wwa" and 'WWA' in genre:
                icon=art+"wwa.jpg"
                addIt=True

            elif type is "defiant" and 'DEFIANT' in genre:
                icon=art+"defiant.jpg"
                addIt=True

            elif type is "evolve" and 'EVOLVE' in genre:
                icon=art+"evolve.jpg"
                addIt=True

            elif type is "ewf" and 'EMPIRE' in genre:
                icon=art+"ewf.jpg"
                addIt=True
				
            elif type is "roh" and 'ROH' in genre:
                icon=art+"roh.jpg"
                addIt=True
				
            elif type is "brit" and 'BRIT' in genre:
                icon=art+"brit.jpg"
                addIt=True
				
            elif type is "capitol" and 'CAPITOL' in genre:
                icon=art+"capitol.jpg"
                addIt=True

            elif type is "ipw" and 'IPW' in genre:
                icon=art+"ipw.jpg"
                addIt=True

            elif type is "lucha" and 'LUCHA' in genre:
                icon=art+"lucha.jpg"
                addIt=True

            elif type is "mlw" and 'MLW' in genre:
                icon=art+"mlw.jpg"
                addIt=True

            elif type is "njpw" and 'NJPW' in genre:
                icon=art+"njpw.jpg"
                addIt=True

            elif type is "row" and 'ROW' in genre:
                icon=art+"row.jpg"
                addIt=True

            elif type is "pcw" and 'PCW' in genre:
                icon=art+"pcw.jpg"
                addIt=True

            elif type is "hob" and 'HOB' in genre:
                icon=art+"hob.jpg"
                addIt=True

            elif type is "hog" and 'HOG' in genre:
                icon=art+"hog.jpg"
                addIt=True

            elif type is "misc" and 'MISC' in genre:
                icon=art+"misc.jpg"
                addIt=True

            elif type is "nwa" and 'NWA' in genre:
                icon=art+"nwa.jpg"
                addIt=True

            elif type is "tmn" and 'TMN' in genre:
                icon=art+"tmn.jpg"
                addIt=True

            elif type is "champ" and 'CHAMP' in genre:
                icon=art+"champ.jpg"
                addIt=True

            elif type is "pwa" and 'PWA' in genre:
                icon=art+"pwa.jpg"
                addIt=True

            elif type is "pwl" and 'PWL' in genre:
                icon=art+"pwl.jpg"
                addIt=True

            elif type is "wlw" and 'WLW' in genre:
                icon=art+"wlw.jpg"
                addIt=True

            elif type is "fwa" and 'FWA' in genre:
                icon=art+"fwa.jpg"
                addIt=True

            elif type is "progress" and 'PROGRESS' in genre:
                icon=art+"progress.jpg"
                addIt=True

            elif type is "rise" and 'RISE' in genre:
                icon=art+"rise.jpg"
                addIt=True

            elif type is "smash" and 'SMASH' in genre:
                icon=art+"smash.jpg"
                addIt=True

            elif type is "ovw" and 'OVW' in genre:
                icon=art+"ovw.jpg"
                addIt=True

            elif type is "tna" and 'TNA' in genre:
                icon=art+"impact.jpg"
                addIt=True

            elif type is "women" and 'WOMEN' in genre:
                icon=art+"wow.jpg"
                addIt=True

            elif type is "wwe" and 'WWE' in genre:
                icon=art+"wwe.jpg"
                addIt=True
		
            if addIt==True:
	            #addLink(name,url,zmode,icon,fanart)
	            addLink(name,url,zmode,theImage,fanart)

#=====================================

