
with open('C://Users/Ray/Desktop/Test3 18.6 PORTABLE/Kodi/portable_data/addons/script.module.jhm/lib/wrestleArchives.py', 'rb') as f:
    for line in f:
        line_list = []
        for char in line:
            line_list.append("%02X" % (char))
        print(' '.join(line_list))
