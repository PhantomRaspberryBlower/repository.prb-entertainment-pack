plugin.video.cartoongo
======================

Kodi Addon for waching videos from animetoon.tv

Play all your favourite cartoons classics