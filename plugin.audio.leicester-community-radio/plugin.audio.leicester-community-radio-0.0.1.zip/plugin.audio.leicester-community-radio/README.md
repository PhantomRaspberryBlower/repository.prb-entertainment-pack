plugin.audio.leicester-community-radio
======================================

Kodi Addon for listening to Leicester Community Radio live broadcasts

Leicester Community Radio started in 2015, run by well known faces from the Leicester music scene. Playing a mix of roots, reggae, dub, R&amp;B, hip-hop, ska, soca as well as house, drum &amp; bass etc. The station aims to provide all Leicester residents with a central source for the best music around.