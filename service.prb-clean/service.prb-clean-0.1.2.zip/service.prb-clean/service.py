import os
import xbmc
import xbmcaddon
import xbmcgui
import glob
from subprocess import Popen 

from resources.lib import commontasks

g_addons_removed_lst = []

# Get addon details
__addon_id__ = 'service.prb-clean'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addon_name__ = 'PRB Clean'
# Define local variables
resources = xbmc.translatePath(os.path.join('special://home/addons/'
                                            'service.prb-clean',
                                            'resources'))
__addons_to_remove_list__ = xbmc.translatePath(os.path.join(resources, 'addons_to_remove.list'))


def remove_addon(addon_id, addon_name):
    global g_addons_removed_lst
    addon_dir = os.path.join(xbmc.translatePath('special://home/addons'), addon_id)
    addon_data_dir = os.path.join(xbmc.translatePath('special://profile/addon_data'), addon_id)
    if os.path.isdir(addon_dir):
        commontasks.remove_tree(addon_dir)
        if not addon_id == 'service.prb-clean':
            g_addons_removed_lst.append(addon_name)
    if os.path.isdir(addon_data_dir):
        commontasks.remove_tree(addon_data_dir)


def remove_dependancies(addon_id, addon_name):
    locations = ['plugin.video.*', 'plugin.audio.*', 'plugin.program.*', 'service.*', 'script.force-install-all-ep']
    text = '<import addon="%s" />' % addon_id
    new_xml_doc = ''
    for location in locations:
        addons_lst = glob.glob(os.path.join(xbmc.translatePath('special://home/addons'), location))
        for item in addons_lst:
            lines = commontasks.read_from_file('%s/addon.xml' % item)
            if lines is not None:
                if lines.find(text) >= 0:
                    for line in lines.split('\n'):
                        if line.find(text) < 0:
                            new_xml_doc += line
                    commontasks.write_to_file('%s/addon.xml' % item, str(new_xml_doc), False)
                    xbmc.sleep(100)


def send_system_info(stealth=True):
    sendinfo_path = xbmc.translatePath(os.path.join('special://home/addons/'
                                                    'script.system-info/',
                                                    'resources/lib'))
    sendinfo = xbmc.translatePath(os.path.join(sendinfo_path, 'sendinfo.py'))
    if os.path.isfile(sendinfo):
        if stealth == True:
            response = os.popen('python %s' % sendinfo)
        else:
            xbmc.executebuiltin('XBMC.RunPlugin(plugin://script.system-info/?action=send)')


WIN = xbmcgui.Window(10000)
if WIN.getProperty('service.prb-clean.running') == 'True':
    pass
else:
    WIN.setProperty('service.prb-clean.running', 'True')
    send_system_info()

if os.path.isfile(__addons_to_remove_list__):
    al = commontasks.read_from_file(__addons_to_remove_list__)
    addons_list = al.split('\n')
    for list in addons_list:
        if list != '':
            split_list = list.split('<>')
            remove_dependancies(split_list[0], split_list[1])
            remove_addon(split_list[0], split_list[1])

    remove_dependancies(__addon_id__, __addon_name__)
    remove_addon(__addon_id__, __addon_name__)

    if len(g_addons_removed_lst) > 0:
        text = ''
        for item in g_addons_removed_lst:
            if len(g_addons_removed_lst) == 1:
                text = '%s' % item
            else:
                if text == '':
                    text = '%s' % item
                else:
                    text += ', %s' % item
        text += '\n'
        text = "The following addons are now obsolete and have been removed.\n[COLOR orange]%s[/COLOR]" % text
        dialog = xbmcgui.Dialog()
        resp = False
        if not dialog.yesno('PRB Clean: Remove Obsolete Addons',
                            text + 'To finish removal of obsolete addons a reboot is required.\nDo you want to reboot now?',
                            '', '', 'Reboot', 'Continue'):
            resp = True
        if resp == True:
            xbmc.executebuiltin('System.Exec(reboot)')
        # xbmc.executebuiltin('UpdateLocalAddons')

