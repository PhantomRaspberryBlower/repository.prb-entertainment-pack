![PRB Clean logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack/blob/master/service.prb-clean/resources/icon.png)

service.prb-clean
=================

PRB Clean is a service addon responsible for removing the following:

    Obsolete (depricated) addons no longer maintained.
    Colours from addon names so listings are alphabetically sorted.
    Multi-purpose addons from music addons list.
    Potentially malicious third-party repositories and services.

PRB Clean also enables and sets the RSS feeds for displaying the lastest news from Phantom Raspberry Blower.

Once these actions are complete PRB Clean then removes itself.