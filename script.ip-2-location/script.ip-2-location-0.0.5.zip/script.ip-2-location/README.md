![RSS Reader logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack/blob/master/script.ip-2-location/resources/icon.png)

script.ip-2-location
====================

Kodi Addon for displaying a location for a given IP address

Founded in 2013 by former Facebook engineer Ben Dowling, IPinfo prides itself on being the most reliable, accurate, and in-depth source of IP address data available anywhere. IPinfo process terabytes of data to produce custom IP geolocation, company, carrier and IP type data sets.

Supply an IP address to see where it's location is or leave blank ie 0.0.0.0 to find your IP address.