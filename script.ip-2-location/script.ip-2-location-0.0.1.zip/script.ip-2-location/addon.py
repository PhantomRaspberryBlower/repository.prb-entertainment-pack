#!/bin/python

import xbmc
import xbmcgui
import xbmcaddon
import urllib2
import re
import sys
import os

# Written by: Phantom Raspberry Blower (The PRB)
# Date: 21-09-2018
# Description: Addon for displaying a location for a given IP address

# Get addon details
__addon_id__ = 'script.ip-2-location'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
__fanart__ = __addon__.getAddonInfo('fanart')
__author__ = 'Phantom Raspberry Blower'


def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        r = re.search("(?i)" + from_string +
                      "([\S\s]+?)" +
                      to_string, text).group(1)
    else:
        r = re.search("(?i)(" +
                      from_string +
                      "[\S\s]+?" +
                      to_string +
                      ")", text).group(1)
    return r


def _get_url(url):
    """
    Download url and remove carriage return
    and tab spaces from page
    """
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows; '
                       'U; Windows NT 5.1; en-GB; '
                       'rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
    	 notification("Error!",
                      "Unable to downloads url!",
                      __icon__,
                      5000)


def  ip2location(name, url):
    """
    Show Location
    """
    response = _get_url(url)
    address = regex_from_to(response.replace('\t', '').replace('\n', '').replace('  ', ''), '<div class="address-inner">', '</div></div></div></div>')

    match1 = re.compile('<li class="clearfix">(.+?)</li>').findall(address)
    text = ''
    for item in match1:
        match2 = re.compile('<span class="address-list-left">(.+?)</span><spa(.+?)>(.+?)</span>').findall(item)
        for key, junk, value in match2:
            if '<a' in value:
                value = regex_from_to(value, '">', '</a>')
            text += ('%s: %s\n') % (key, value)

    city = regex_from_to(text, 'City: ', '\n')
    region = regex_from_to(text, 'Region: ', '\n')
    postcode = regex_from_to(text, 'Postal Code: ', '\n')
    coordinates = regex_from_to(text, 'Coordinates : ', '\n')
    country = regex_from_to(text, 'Country: ', '\n')
    hostname = regex_from_to(text, 'Hostname: ', '\n')
    addr_type = regex_from_to(text, 'Address type: ', '\n')
    asn = regex_from_to(text, 'ASN: ', '\n')
    organization = regex_from_to(text, 'Organization: ', '\n')
    route = regex_from_to(text, 'Route: ', '\n')
    lat_lon = coordinates
    api_key = 'AIzaSyDIJ9XX2ZvRKCJcFRrl-lRanEtFUow4piM'
    image_size = '480x390'
    map_image = 'https://maps.googleapis.com/maps/api/staticmap?center=%s&zoom=11&&size=%s&key=%s' % (lat_lon, image_size, api_key)

    window = xbmcgui.WindowXMLDialog('script-ip-2-location.xml', __addon__.getAddonInfo('path'))
    win = xbmcgui.Window(10147)
    win.setProperty('HeadingLabel', 'Location for IP Address: ' + name)
    win.setProperty('MapImage', map_image)
    win.setProperty('Region', region)
    win.setProperty('City', city)
    win.setProperty('PostCode', postcode)
    win.setProperty('Coordinates', coordinates)
    win.setProperty('Country', country)
    win.setProperty('Hostname', hostname)
    win.setProperty('AddressType', addr_type)
    win.setProperty('ASN', asn)
    win.setProperty('Organization', organization)
    win.setProperty('Route', route)

    #response = _get_url('https://en.wikipedia.org/wiki/%s' % city)
    url = 'https://en.wikipedia.org/w/api.php?action=query&prop=extracts&titles=%s&exintro=&exsentences=2&explaintext=&redirects=&formatversion=2&format=json' % city
    response = _get_url(url)
    desc = regex_from_to(response, ',"extract":"', '"}]}')
    win.setProperty('Description', desc)
    window.doModal()
    del window

def wan_ip_addr():
    # Get the WAN IP address
    try:
        return _get_url('http://ip.42.pl/raw')
    except:
        return 'Error getting WAN IP Address!'

def notification(message, title, icon, duration):
    # Show message notification
    dialog = xbmcgui.Dialog()
    dialog.notification(title, message, icon, duration)


def message(message, title):
    # Display message to user
    dialog = xbmcgui.Dialog()
    dialog.ok(title, message)


dialog = xbmcgui.Dialog()
ip_addr = dialog.input('Enter IP Address', type=xbmcgui.INPUT_IPADDRESS)
if ip_addr == '0.0.0.0':
    ip_addr = wan_ip_addr()
    if ip_addr == 'Error getting WAN IP Address!':
        ip_addr = '0.0.0.0'
if ip_addr:
    ip2location(ip_addr, 'https://ipinfo.io/%s' % ip_addr)
