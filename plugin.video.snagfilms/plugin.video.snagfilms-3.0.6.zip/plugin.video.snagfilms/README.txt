plugin.video.snagfilms
================

Kodi Addon for Snagfilms website

Version 3.0.6 website change
Version 3.0.5 website change
Version 3.0.4 website change
Version 3.0.3 website change
Version 3.0.2 Added "Add to Library"
Version 3.0.1 Isengard version - separate scraper
