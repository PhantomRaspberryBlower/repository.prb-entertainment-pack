# plugin.video.freelivetv.tva

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/44937ae907ae416a831c6b6bb2024b5f)](https://app.codacy.com/app/mhancoc7/plugin.video.freelivetv.tva?utm_source=github.com&utm_medium=referral&utm_content=mhancoc7/plugin.video.freelivetv.tva&utm_campaign=Badge_Grade_Dashboard)

## Submit issues via m7 Kodi Addons

[m7_kodi_addons](https://m7kodi.dev)

If you would like to help support my efforts please consider becoming a supporter at Patreon.

[![Patreon](./resources/images/patreon.jpg)](https://www.patreon.com/bozodev?fan_landing=true)
