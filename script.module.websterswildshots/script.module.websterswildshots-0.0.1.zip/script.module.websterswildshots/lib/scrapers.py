#!/usr/bin/python
# -*- coding: utf-8 -*-

import re
import json
import urllib2
import time
from random import randint
from BeautifulSoup import BeautifulSoup, BeautifulStoneSoup
from CommonFunctions import parseDOM, stripTags
import HTMLParser

try:
    import xbmc
    XBMC_MODE = True
except ImportError:
    XBMC_MODE = False

RETRY_TIME = 5.0

ALL_SCRAPERS = (
    'LivingWild',
    'WebstersWildshots',
)


class BasePlugin(object):

    _title = ''
    _id = 0

    def __init__(self, _id):
        self._albums = []
        self._photos = {}
        self._id = _id
        self._parser = HTMLParser.HTMLParser()

    def get_albums(self):
        return self._albums or self._get_albums()

    def get_photos(self, album_url):
        return self._photos.get(album_url) or self._get_photos(album_url)

    def _get_albums(self):
        raise NotImplementedError

    def _get_photos(self, album_url):
        raise NotImplementedError

    def _get_tree(self, url, language='html'):
        html = self._get_html(url)
        try:
            tree = BeautifulSoup(html, convertEntities=language)
        except TypeError:
            # Temporary fix for wrong encoded utf-8 chars in NewYork
            # Times Lens Blog. Shame on you.
            html = html.decode('utf-8', 'ignore')
            tree = BeautifulSoup(html, convertEntities=language)
        return tree

    def _get_html(self, url, retries=5):
        req = urllib2.Request(url)
        html = ''
        retry_counter=0
        while True:
            try:
                html = urllib2.urlopen(req).read()
                break
            except urllib2.HTTPError as ex:
                if (re.match(r'.+HTTP Error 301.+', str(ex))):
                    raise
                retry_counter += retry_counter
                time.sleep(RETRY_TIME + randint(0, 2*retries))
                pass
            if retry_counter >= retries:
                break
        return html

    def _collapse(self, iterable):
        return u''.join([e.string.strip() for e in iterable if e.string])

    @property
    def title(self):
        return self._title

    @classmethod
    def get_scrapers(cls, name_list):
        enabled_scrapers = []
        for sub_class in cls.__subclasses__():
            if sub_class.__name__ in name_list:
                enabled_scrapers.append(sub_class)
        return enabled_scrapers


class LivingWild(BasePlugin):

    _title = 'Living Wild:'

    def _get_albums(self):
        self._albums = []
        url = 'https://www.bostonglobe.com/news/bigpicture'
        html = self._get_html(url)
        for _id, album in enumerate(parseDOM(html, 'section')):
            title = parseDOM(album, 'a')[0]
            album_url = 'https://www.bostonglobe.com' + parseDOM(album, 'a', ret='href')[0]
            d = parseDOM(album, 'div', attrs={'class': 'subhead geor'})[0]
            if not d:
                continue
            description = stripTags(self._parser.unescape(d))
            pic = urllib2.quote(parseDOM(album, 'img', ret='src')[0])
            if not pic:
                continue
            self._albums.append({
                'title': title,
               'album_id': _id,
               'pic': 'http:' + pic,
               'description': description,
               'album_url': album_url
               })

        return self._albums

    def _get_photos(self, album_url):
        self._photos[album_url] = []
        html = self._get_html(album_url)
        album_title = parseDOM(html, 'title')[0]
        images = parseDOM(html, 'div', attrs={'class': 'photo'})
        descs = parseDOM(html, 'article', attrs={'class': 'pcaption'})
        for _id, photo in enumerate(images):
            pic = urllib2.quote(parseDOM(photo, 'img', ret='src')[0])
            description = stripTags(self._parser.unescape(parseDOM(descs[_id], 'div', attrs={'class': 'gcaption geor'})[0]))
            self._photos[album_url].append({
                'title': '%d - %s' % (_id + 1, album_title),
               'album_title': album_title,
               'photo_id': _id,
               'pic': 'http:' + pic,
               'description': description,
               'album_url': album_url
               })

        return self._photos[album_url]


class WebstersWildshots(BasePlugin):

    _title = 'Websters Wildshots'

    def _get_albums(self):
        img = ''
        url = 'http://living-wild.net/blog/'
        html = self._get_html(url)
        html = html.replace('\n', '').replace('\t', '').replace('\r', '')
        posts = re.compile('<div class="tesseract-post tesseract-post-vertical">(.+?)</div></div></div>').findall(html)
        _id = 1
        print str(len(posts))
        for post in posts:
            date = re.compile('<div class="author-and-date">(.+?)</div>').findall(post)[0]
            lnk_title = re.compile('<a href="(.+?)">(.+?)</a>').findall(post)[0]
            href = lnk_title[0]
            title = unicode(BeautifulStoneSoup(lnk_title[1], convertEntities=BeautifulStoneSoup.ALL_ENTITIES))
            desc = re.compile('<div class="content">(.+?)<img class=').findall(post)[0]
            desc = unicode(BeautifulStoneSoup(desc, convertEntities=BeautifulStoneSoup.ALL_ENTITIES))
            desc = re.sub("<h.>", "\n", desc)
            desc = (desc.replace('<li>', '\n - ')
                       .replace('</li>', '. \n'))
            desc = desc.replace('..', '.').replace('\n\n', '\n')
            best_img = ''
            best_img_size = 0
            try:
                clss, src, width, height, srcset, sizes = re.compile('<img class="(.+?)" src="(.+?)" alt="" width="(.+?)" height="(.+?)" srcset="(.+?)" sizes="(.+?)" />').findall(post)[0]
                imgs = srcset.split('w, ')
                for image in imgs:
                    img = image.split(' ')
                    img_size = int(str(img[1].replace('w', '')))
                    if img_size > best_img_size:
                        best_img_size = img_size
                        best_img = img[0]
            except:
                try:
                    clss, src = re.compile('<img class="(.+?)" src="(.+?)"').findall(post)[0]
                    best_img = src
                except: pass
            self._albums.append({
                'title': '%s - (%s)' % (stripTags(title), date),
                'album_id': _id,
                'pic': best_img,
                'description': stripTags(desc),
                'album_url': href
                })
            _id += 1

#        pattern = r'@media\(min-width:\s*1632px\)\s*{\s*#river1 \.lead-image\s*{\s*background-image:\s*url\((.+?)\)'
#        for _id, li in enumerate(parseDOM(html, 'li', attrs={'class': 'article'})):
#            headline = parseDOM(li, 'h1')[0]
#            match = re.search(pattern.replace('river1', 'river%d' % (_id + 1)), html)
#            if match:
#                self._albums.append({
#                   'title': parseDOM(headline, 'a')[0],
#                   'album_id': _id,
#                   'pic': match.group(1),
#                   'description': stripTags(self._parser.unescape(parseDOM(li, 'p', attrs={'class': 'dek'})[0])),
#                   'album_url': 'https://www.theatlantic.com' + parseDOM(headline, 'a', ret='href')[0]
#                   })

        return self._albums

    def _get_photos(self, album_url):
        self._photos[album_url] = []
        img = ''
        html = self._get_html(album_url)
        html = html.replace('\n', '').replace('\t', '').replace('\r', '')
        article = re.compile('<article (.+?)</article>').findall(html)
        album_title = re.compile('<div id="blogpost_title"><h1 class="entry-title">(.+?)</h1>').findall(article[0])
        album_title = unicode(BeautifulStoneSoup(album_title[0], convertEntities=BeautifulStoneSoup.ALL_ENTITIES))
        _id = 0
        i = 0
        images = re.compile('srcset="(.+?)"').findall(article[0])
        len_images = len(images)
        descs = re.compile('sizes="(.+?)" /></p>(.+?)<p><(.+?) class=').findall(article[0])
        last_desc = re.compile(images[len_images-1] + '" sizes="(.+?)" /></p>(.+?)</p>(.+?)<a class="synved').findall(article[0])
        descs.append(['', str(last_desc[0][2]), ''])
        for srcset in images:
            best_img = ''
            best_img_size = 0
            try:
                imgs = srcset.split('w, ')
                for image in imgs:
                    img = image.split(' ')
                    img_size = int(str(img[1].replace('w', '')))
                    if img_size > best_img_size:
                        best_img_size = img_size
                        best_img = img[0]
                desc = unicode(BeautifulStoneSoup(descs[i][1], convertEntities=BeautifulStoneSoup.ALL_ENTITIES))
            except: pass
            self._photos[album_url].append({'title': '%d - %s' % (_id + 1, stripTags(album_title)),
               'album_title': album_title[0],
               'photo_id': _id,
               'pic': best_img,
               'description': stripTags(desc).replace(u'Â', u''),
               'album_url': album_url
               })
            _id += 1
            i += 1



#        self._photos[album_url] = []
#        html = self._get_html(album_url)
#        pattern = r'data-share-image=\"(.+?)\"'
#        match_image = re.findall(pattern, html)
#        album_title = self._parser.unescape(parseDOM(html, 'title')[0])
#        for _id, p in enumerate(parseDOM(html, 'p', attrs={'class': 'caption'})):
#            match_description = re.search('<span>(.+?)</span>', p)
#            if match_description:
#                self._photos[album_url].append({'title': '%d - %s' % (_id + 1, album_title),
#                   'album_title': album_title,
#                   'photo_id': _id,
#                   'pic': match_image[_id * 2],
#                   'description': stripTags(self._parser.unescape(match_description.group(1))),
#                   'album_url': album_url
#                   })

        return self._photos[album_url]


def get_scrapers(enabled_scrapers=None):
    if enabled_scrapers is None:
        enabled_scrapers = ALL_SCRAPERS
    scrapers = [
        scraper(i) for i, scraper
        in enumerate(BasePlugin.get_scrapers(enabled_scrapers))
    ]
    return scrapers
