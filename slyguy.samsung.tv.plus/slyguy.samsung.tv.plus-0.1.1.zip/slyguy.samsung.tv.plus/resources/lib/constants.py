DATA_URL = 'https://i.mjh.nz/SamsungTVPlus/app.json.gz'
ALL = '_'
