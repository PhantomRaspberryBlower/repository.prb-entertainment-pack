plugin.audio.demon-fm
======================================

Kodi Addon for listening to Demon FM

DemonFM is a student radio station based at De Montfort University in Leicester, England. The station is simulcast on FM and online on a 24/7 basis and was set up in 1995 by the Communications Officer of the time, Rob Martin.
