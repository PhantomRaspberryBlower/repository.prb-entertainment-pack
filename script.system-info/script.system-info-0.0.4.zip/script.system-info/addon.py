#!/bin/python

import xbmc
import xbmcgui
import xbmcaddon

import os
import re
import requests
from subprocess import Popen
#from resources.lib.systeminfo import SystemInfo

# Written by: Phantom Raspberry Blower (The PRB)
# Date: 01-10-2018
# Description: Addon for displaying system information
#              about software, CPU, hardware, memory,
#              storage, networks.
#              Tested on Raspberry Pi's.

# Get addon details
__addon_id__ = 'script.system-info'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
__fanart__ = __addon__.getAddonInfo('fanart')
__author__ = 'Phantom Raspberry Blower'
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

# Get localized language text
__language__ = __addon__.getLocalizedString
_software = __language__(30102)
_cpu = __language__(30114)
_memory = __language__(30121)
_storage = __language__(30142)
_network = __language__(30125)
_previous_networks = __language__(30144)
_network_devices = __language__(30143)

_addon_resources_lib_path_ = xbmc.translatePath(os.path.join('special://home/addons/',
                                                __addon_id__ + '/resources/lib/'))

def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            quit()
            return
        except: pass


def get_params():
    """
    Get the current parameters
    :return: param[]
    """
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring[1:])>=1:
        params=paramstring[1:]
        pairsofparams=params.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def notification(message, title, icon, duration):
    # Show message notification
    dialog = xbmcgui.Dialog()
    dialog.notification(title, message, icon, duration)


if __name__ == '__main__':
    heading_lst = [_software + ':',
                   _cpu + ':',
                   _memory + ':',
                   _storage + ':',
                   _network + ':',
                   _previous_networks + ':',
                   _network_devices + ':']
    response = ''
    params=get_params()
    # Check the parameters passed to the addon
    if params:
        if params['action'] == 'send':
            for line in os.popen('sudo python %ssendinfo.py' % _addon_resources_lib_path_):
                response = response + line
            notification(response, "[COLOR orange]Form Sent[/COLOR]", __icon__, 5000)
    else:
        for line in os.popen('sudo python %ssysteminfo.py' % _addon_resources_lib_path_):
            response = response + line.replace('\t', '').replace(':', ': ')
        for item in heading_lst:
            response = response.replace('\n%s' % (item), '[COLOR orange]\n%s[/COLOR]' % (item))
        showText('System Info', response)
