#!/bin/python

import xbmc
import xbmcgui
import xbmcaddon
#from resources.lib.systeminfo import SystemInfo
from subprocess import Popen
import os

# Written by: Phantom Raspberry Blower (The PRB)
# Date: 01-10-2018
# Description: Addon for displaying system information
#              about software, CPU, hardware, memory,
#              storage, networks.

# Get addon details
__addon_id__ = 'script.system-info'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
__fanart__ = __addon__.getAddonInfo('fanart')
__author__ = 'Phantom Raspberry Blower'
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

# Get localized language text
__language__ = __addon__.getLocalizedString
_software = __language__(30102)
_cpu = __language__(30114)
_memory = __language__(30121)
_storage = __language__(30142)
_network = __language__(30125)
_previous_networks = __language__(30144)
_network_devices = __language__(30143)


def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            quit()
            return
        except: pass

if __name__ == '__main__':
    heading_lst = [_software + ':', _cpu + ':', _memory + ':', _storage + ':', _network + ':', _previous_networks + ':', _network_devices + ':']
    response = ''
    for line in os.popen('sudo python /home/osmc/.kodi/addons/script.system-info/resources/lib/systeminfo.py'):
        response = response + line.replace('\t', '').replace(':', ': ')
    for item in heading_lst:
        response = response.replace('\n%s' % (item), '[COLOR orange]\n%s[/COLOR]' % (item))
    showText('System Info', response)
