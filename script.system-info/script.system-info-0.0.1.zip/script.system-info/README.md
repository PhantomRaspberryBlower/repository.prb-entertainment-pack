![RSS Reader logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack/blob/master/script.system-info/resources/icon.png)

script.system-info
==================

Displays information about Software, CPU, Hardware, Memory, Storage and Network settings. Including connections to previous networks along with WiFi passphrase.
