![PRB AVSS logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack/blob/master/plugin.video.prb-avss/resources/icon.png)

plugin.video.prb-avss
===========================

Turns a Raspberry Pi into a audio video streaming service that can either live stream to Facebook or broadcast using UDP.